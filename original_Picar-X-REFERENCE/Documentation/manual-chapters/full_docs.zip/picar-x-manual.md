# **SunFounder PiCar-X Kit**

## **www.sunfounder.com**

**Dec 24, 2025**


### **CONTENTS**

**1** **Assemble the PiCar-X** **5**


**2** **Play with Python** **7**
2.1 1. Quick Guide on Python . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 7
2.1.1 What Else Do You Need? . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 7
2.1.2 Installing the Operating System . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 11
2.1.3 Power Supply for Raspberry Pi (Important) . . . . . . . . . . . . . . . . . . . . . . . . . . 24
2.1.4 Set Up Your Raspberry Pi . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 26
2.1.5 Install All the Modules (Important) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 30
2.1.6 Servo Adjust(Important) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 31
2.2 2. Basic Movement . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 33
2.2.1 1. Calibrating the PiCar-X . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 34
2.2.2 2. Let PiCar-X Move . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 39
2.2.3 3. Keyboard Control . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 43
2.2.4 4. Obstacle Avoidance . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 45
2.2.5 5. Cliff Detection . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 48
2.2.6 6. Line Tracking . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 50
2.3 3. Computer Vision . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 53
2.3.1 7. Computer Vision . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 54
2.3.2 8. Stare at You . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 61
2.3.3 9. Record Video . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 63
2.3.4 10. Bull Fight . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 65
2.3.5 11. Video Car . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 68
2.3.6 12. Controlled by the APP . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 71


**3** **Think · Talk · Drive — AI-Powered with Multi-LLMs** **77**
3.1 13. Play Music and Sound Effects . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 77
3.2 14. Voice Prompt Car with Espeak and Pico2Wave . . . . . . . . . . . . . . . . . . . . . . . . . . . 79
3.2.1 Before You Start . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 79
3.2.2 1. Testing Espeak . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 79
3.2.3 2. Testing Pico2Wave . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 80
3.2.4 3. Voice Prompt Car . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 81
3.2.5 Troubleshooting . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 82
3.2.6 Comparison: Espeak vs Pico2Wave . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 82
3.3 15. AI Storytelling Robot with Piper and OpenAI . . . . . . . . . . . . . . . . . . . . . . . . . . . . 83
3.3.1 Before You Start . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 83
3.3.2 1. Testing Piper . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 83
3.3.3 2. Testing OpenAI TTS . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 84
3.3.4 3. Storytelling Robot . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 88
3.3.5 Troubleshooting . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 89


**i**


3.3.6 Comparison of TTS Engines . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 90
3.4 16. Voice Controlled Car with Vosk (Offline) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 91
3.4.1 Before You Start . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 91
3.4.2 1. Check Your Microphone . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 91
3.4.3 2. Test Vosk . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 92
3.4.4 3. Voice Controlled Car . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 93
3.4.5 Troubleshooting . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 95
3.5 17. Text Vision Talk with Ollama . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 96
3.5.1 Before You Start . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 96
3.5.2 1. Install Ollama (LLM) and Download Model . . . . . . . . . . . . . . . . . . . . . . . . 96
3.5.3 2. Test Ollama . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 99
3.5.4 3. Vision Talk with Ollama . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 100
3.5.5 Troubleshooting . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 103
3.6 18. Connecting to Online LLMs . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 104
3.6.1 Before You Start . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 104
3.6.2 OpenAI . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 104
3.6.3 Gemini . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 108
3.6.4 Qwen . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 112
3.6.5 Grok (xAI) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 115
3.6.6 DeepSeek . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 118
3.6.7 Doubao . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 120
3.6.8 General . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 127
3.7 19. Local Voice Chatbot . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 128
3.7.1 Before You Start . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 128
3.7.2 Run the Code . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 129
3.7.3 Code . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 129
3.7.4 Code Analysis . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 131
3.7.5 Troubleshooting & FAQ . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 134
3.8 20. Treasure Hunt . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 134
3.8.1 Before You Start . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 135
3.8.2 Run the Code . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 135
3.8.3 Game Rules . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 135
3.8.4 Code . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 135
3.8.5 How It Works . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 138
3.8.6 Troubleshooting . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 139
3.9 21. AI Voice Assistant Car . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 139
3.9.1 Before You Start . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 140
3.9.2 Run the Example . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 140
3.9.3 What Will Happen . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 141
3.9.4 Switching to Other LLMs or TTS . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 141
3.9.5 Action & Sound Reference . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 142
3.9.6 Troubleshooting . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 143


**4** **Python Video Course** **145**
4.1 Video A1: Starting with Raspbrry Pi . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 145
4.2 Video A2: Assembly of the PICAR-X . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 146
4.3 Video A3: Calibrate the PiCar-X . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 147
4.4 Video 1: Motor Move and Steering Control . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 148
4.5 Video 2: Controlling the PiCar-X using keyboard . . . . . . . . . . . . . . . . . . . . . . . . . . . . 148
4.6 Video 3: Text to Speech . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 149
4.7 Video 4: Obstacle Avoidance with Ultrasonic . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 150
4.8 Video 5: Greyscale Line Tracking . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 151
4.9 Video 6: Cliff Detection . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 151
4.10 Video 7: PiCar-X Computer Vision . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 152


**ii**


4.11 Video 8: PiCar-X Stares at You . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 153
4.12 Video 9: Recording Video . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 154
4.13 Video 10: Bull Fight with PiCar-X . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 154
4.14 Video 11: PiCar-X as Video Car . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 155
4.15 Video 12: Treasure Hunt Game . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 156
4.16 Video 12: Control PiCAR-X Robot Car use mobile app . . . . . . . . . . . . . . . . . . . . . . . . . 157


**5** **Play with Ezblock** **159**
5.1 Quick Guide on EzBlock . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 159
5.2 Install and Configure EzBlock Studio . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 163
5.3 Calibrate the Car . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 164
5.4 Move . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 168
5.5 Remote Control . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 172
5.6 Test Ultrasonic Module . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 174
5.7 Test Grayscale Module . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 177
5.8 Color Detection . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 178
5.9 Face Detection . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 181
5.10 Sound Effect . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 185
5.11 Background Music . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 186
5.12 Say Hello . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 188
5.13 Music Car . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 191
5.14 Cliff Detection . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 192
5.15 Minecart . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 196
5.16 Minecart Plus . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 200
5.17 Bullfight . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 205
5.18 Beware of Pedestrians . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 207
5.19 Traffic Sign Detection . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 209
5.20 Orienteering . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 213


**6** **Adjust Servo for Assembly** **219**
6.1 For Python Users . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 220
6.2 For Ezblock Users . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 220


**7** **Appendix** **221**
7.1 I [2] C Configuration . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 221
7.1.1 Enable the I [2] C Interface . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 221
7.1.2 Check I [2] C Kernel Modules . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 223
7.1.3 Install i2c-tools . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 223
7.1.4 Detect Connected I [2] C Devices . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 224
7.1.5 Install the Python I [2] C Library . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 224
7.2 SPI Configuration . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 225
7.2.1 Enable the SPI Interface . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 225
7.2.2 Verify SPI Interface . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 227
7.2.3 Install spidev (Python SPI Library) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 227
7.3 Remote Desktop . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 227
7.3.1 Enable the VNC Service . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 228
7.3.2 Log in with RealVNC® Viewer . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 230
7.3.3 Additional Notes . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 233
7.4 FileZilla Software . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 234
7.4.1 Download FileZilla . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 234
7.5 Install OpenSSH via PowerShell . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 237
7.6 PuTTY . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 238


**8** **Hardware** **243**
8.1 Robot HAT . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 243


**iii**


8.2 Camera Module . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 244
8.3 Ultrasonic Module . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 246
8.4 3-pin Battery . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 248


**9** **FAQ** **251**
9.1 Q1: After installing Ezblock OS, the servo can’t turn to 0°? . . . . . . . . . . . . . . . . . . . . . . 251
9.2 Q2: When using VNC, I am prompted that the desktop cannot be displayed at the moment? . . . . . 252
9.3 Q3: Why does the servo sometimes return to the middle position for no reason? . . . . . . . . . . . . 252
9.4 Q4: About the Robot HAT Detailed Tutorial? . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 252
9.5 Q5: About the Battery Charger? . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 252
9.6 Q6: Camera Not Working? . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 253


**10 Copyright Notice** **255**


**iv**


**SunFounder PiCar-X Kit**


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!


   

Thanks for choosing our .


**Note:** This document is available in the following languages.


   

   

   

   

   

   

   

Please click on the respective links to access the document in your preferred language.


**CONTENTS** **1**


**SunFounder PiCar-X Kit**


The PiCar-X is an AI-driven self-driving robot car for the Raspberry Pi platform, upon which the Raspberry Pi acts as
the control center. The PiCar-X’s 2-axis camera module, ultrasonic module, and line tracking modules can provide the
functions of color/face/traffic-signs detection, automatic obstacle avoidance, automatic line tracking, etc.


PiCar-X has two programming languages: Blockly and Python. No matter what language you program in, you’ll find
detailed steps to teach you everything from configuring the Raspberry Pi to running the relevant example code.


   - _Play with Python_


**–** This chapter is for those who enjoy programming in Python or want to learn the Python language.


**–** To get Picar-X working properly, you must install some libraries first.


**–** The Raspberry Pi configuration and samples code for the PiCar-X are provided in this chapter.


**–** An APP - SunFounder Controller is also provided to allow you to remotely control the PiCar-X on your
mobile device.


   - _Play with Ezblock_


**–** In this section, you will use a Blockly based APP, Ezblock Studio, which, like Scratch, allows you to drag
and drop blocks to make Picar-X move.


**–** It is required to reinstall the SD card with the operating system we provide with pre-installed Ezblock
environment before programming. It is recommended to use a new or unused TF card for this section.


**–** Ezblock Studio is available for nearly all types of devices, including Macs, PCs, and Androids.


**–** Ezblock Studio is a good choice if you are 6-12 years old, or don’t have programming skills, or want to test
Picar-X quickly.


**Content**


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


**2** **CONTENTS**


**SunFounder PiCar-X Kit**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!


**CONTENTS** **3**


**SunFounder PiCar-X Kit**


**4** **CONTENTS**


**CHAPTER**

### **ONE** **ASSEMBLE THE PICAR-X**


Before assembling the PiCar-X, please first verify that all parts and components have been included. If there are any
[missing or damaged components, please contact SunFounder immediately at service@sunfounder.com to resolve the](mailto:service@sunfounder.com)
issue as soon as possible.


This video will walk you through the process of assembling your robot from scratch.


**Note:** The assembly steps in the video may differ slightly from the printed instructions you have. Please prioritize
following the printed instructions. If any steps are unclear, you can refer to the video for further clarification.


In this tutorial, you will learn:


   - **Preparation** : We’ll introduce you to all the tools and parts needed, ensuring you’re fully equipped before starting
the assembly.


   - **Assembly Steps** : We’ll demonstrate each assembly step in a systematic manner.


   - **Tips and Considerations** : Throughout the process, we’ll share essential tips and tricks to help you avoid common mistakes and ensure your car operates smoothly.


   - **Zeroing a Servo** : Before fixing each servo, it needs to be zeroed first. The steps for zeroing are to first install
the Raspberry Pi OS, then install the required modules, and then run a script (set the angle of all PWM pins to
0). After that, plug in the servo wire to zero the servo.


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!


**5**


**SunFounder PiCar-X Kit**


**6** **Chapter 1. Assemble the PiCar-X**


**CHAPTER**

### **TWO** **PLAY WITH PYTHON**


For novices and beginners wishing to program in Python, some basic Python skills and familiarity with the Raspberry
Pi OS are helpful. This section will guide you step by step — from setting up your Raspberry Pi, to moving PiCar-X,
to using computer vision, and finally adding voice and AI interaction.

### **2.1 1. Quick Guide on Python**


Learn how to set up your Raspberry Pi environment: install Raspberry Pi OS, configure Wi-Fi, and enable remote
access so you can run Python code easily. If you already know how to use Raspberry Pi and access its command line,
you may skip directly to the later parts.


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!


**2.1.1 What Else Do You Need?**


Before we start playing with this kit, let’s prepare the essential hardware.


**7**


**SunFounder PiCar-X Kit**


**Required Components**


   - **Raspberry Pi**


The Raspberry Pi acts as the **brain**, handling all computing, sensing, and control tasks.


**– Compatible models** : Raspberry Pi 5, Raspberry Pi 4, 3, or Raspberry Pi Zero 2W


   - **Power Adapter**


Prepare a suitable power supply based on your Raspberry Pi model:


**– Raspberry Pi 5** : 5V 5A USB-C (recommended: official 27W PD power supply).


**– Raspberry Pi 4** : 5V 3A USB-C.


**8** **Chapter 2. Play with Python**


**SunFounder PiCar-X Kit**


**– Raspberry Pi 3B/3B+** : 5V 2.5A Micro-USB.


**– Raspberry Pi Zero 2W** : 5V 2A Micro-USB.


Using a stable power source helps prevent undervoltage and ensures reliable operation.


   - **Micro SD Card**


The Raspberry Pi does not have a built-in hard drive. It boots and stores all files on a **Micro SD card** .


**–** Minimum: **16GB**


**–** Recommended: **32GB** for better stability


**–** Brand: Use reliable options such as **SanDisk** or **Samsung** to avoid read/write errors


**Optional Components**


Although not strictly required, the following peripherals will greatly improve your learning and debugging experience:


   - **Monitor (HDMI or TV)**


For beginners, we strongly recommend a display with an HDMI input, so you can easily configure Raspberry Pi
OS and run graphical programs.


**2.1. 1. Quick Guide on Python** **9**


**SunFounder PiCar-X Kit**


   - **HDMI Cable (Standard / Mini / Micro)**


Different Raspberry Pi models use different HDMI connectors, be sure to check your Pi model and prepare the
correct cable.


**– Raspberry Pi 4 / 5** : Micro HDMI


**– Raspberry Pi 3** : Standard HDMI


**– Raspberry Pi Zero 2W** : Mini HDMI


   - **Keyboard & Mouse**


Very useful during the initial setup of Raspberry Pi OS. Later, you may switch to remote access (SSH/VNC),
but for beginners we recommend preparing a basic USB or wireless set.


**Tips for Preparation**


  - If you purchased this kit, most accessories are included, but you still need to prepare the Raspberry Pi board,
Micro SD card, and power adapter separately.


  - Not sure what to buy? The most stable and universal choice is: **Raspberry Pi 4/5 (2GB) + Official Power**
**Supply + 32GB Micro SD card** .


**10** **Chapter 2. Play with Python**


**SunFounder PiCar-X Kit**


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!


**2.1.2 Installing the Operating System**


Before using your Raspberry Pi, you need to install **Raspberry Pi OS** onto a microSD card. This guide explains how
to do that using **Raspberry Pi Imager** in a simple, beginner-friendly way.


**Required Components**


  - A computer (Windows, macOS, or Linux)


  - A microSD card (16GB or larger; recommended brands: SanDisk, Samsung)


  - A microSD card reader


**2.1. 1. Quick Guide on Python** **11**


**SunFounder PiCar-X Kit**


**1. Install Raspberry Pi Imager**


1. Visit the official Raspberry Pi Imager download page: . Download the correct installer for your operating system.


2. Follow the installation prompts (language, install path, confirmation). After installation, launch **Raspberry Pi**
**Imager** from your desktop or applications menu.


**12** **Chapter 2. Play with Python**


**SunFounder PiCar-X Kit**


**2. Install the OS to the microSD Card**


1. Insert your microSD card into your computer using a card reader. Back up any important data before proceeding.


2. When Raspberry Pi Imager opens, you will see the **Device** page. Select your Raspberry Pi model from the list
(e.g., Raspberry Pi 5, 4, 3, or Zero 2W).


**2.1. 1. Quick Guide on Python** **13**


**SunFounder PiCar-X Kit**


3. Go to the **OS** section and choose the recommended **Raspberry Pi OS (64-bit)** option.


4. In the **Storage** section, select your microSD card. For safety, unplug other USB drives so only the SD card
appears in the list.


**14** **Chapter 2. Play with Python**


**SunFounder PiCar-X Kit**


5. Click **Next** to continue to the customization step.


**Note:**


     - If you will connect a monitor, keyboard, and mouse directly to your Raspberry Pi, you may click **SKIP**
**CUSTOMISATION** .


     - If you plan to set up the Raspberry Pi _headless_ (Wi-Fi remote access), you must complete the customization
settings.


**2.1. 1. Quick Guide on Python** **15**


**SunFounder PiCar-X Kit**


**3. OS Customization Settings**


1. **Set Hostname**


     - Give your Raspberry Pi a unique hostname.


     - You can connect to it later using `hostname.local` .


**16** **Chapter 2. Play with Python**


**SunFounder PiCar-X Kit**


2. **Set Localisation**


     - Choose your capital city.


     - Imager will auto-complete the time zone and keyboard layout based on your selection, though you can
adjust them if needed. Select Next.


**2.1. 1. Quick Guide on Python** **17**


**SunFounder PiCar-X Kit**


3. **Set Username & Password**


Create a user account for your Raspberry Pi.


4. **Configure Wi-Fi**


     - Enter your Wi-Fi **SSID** (network name) and **password** .


     - Your Raspberry Pi will automatically connect on first boot.


**18** **Chapter 2. Play with Python**


**SunFounder PiCar-X Kit**


5. **Enable SSH (Optional but Recommended)**


     - Enabling SSH allows you to remotely log in from your computer.


     - You may log in using your username/password or configure SSH keys.


**2.1. 1. Quick Guide on Python** **19**


**SunFounder PiCar-X Kit**


6. **Enable Raspberry Pi Connect (Optional)**


Raspberry Pi Connect allows you to access your Raspberry Pi desktop from a web browser.


     - Turn on **Raspberry Pi Connect**, then click **OPEN RASPBERRY PI CONNECT** .


     - The Raspberry Pi Connect website will open in your default browser. Log in to your Raspberry Pi ID
account, or sign up if you don’t have one yet.


     - On the **New auth key** page, create your one-time auth key.


**–** If your Raspberry Pi ID account isn’t part of any organisation, select **Create auth key and launch**
**Raspberry Pi Imager** .


**–** If you belong to one or more organisations, choose one, then create the key and launch Imager.


**–** Make sure to power on your Raspberry Pi and connect it to the internet before the key expires.


**20** **Chapter 2. Play with Python**


**SunFounder PiCar-X Kit**


     - Your browser may ask to open Raspberry Pi Imager — allow it.


**–** Imager will open on the Raspberry Pi Connect tab, showing the authentication token.


**–** If the token doesn’t transfer automatically, open the **Having trouble?** section on the Raspberry Pi
Connect page, copy the token, and paste it into Imager manually.


**4. Write the OS Image**


1. Review all settings and click **WRITE** .


**2.1. 1. Quick Guide on Python** **21**


**SunFounder PiCar-X Kit**


2. If the card already contains data, Raspberry Pi Imager will show a warning that all data on the device will be
erased. Double-check that you selected the correct drive, then click **I UNDERSTAND, ERASE AND WRITE**
to continue.


3. Wait for the writing and verification to finish. When it is done, Raspberry Pi Imager will show **Write complete!**
and a summary of your choices. The storage device will be ejected automatically so you can remove it safely.


**22** **Chapter 2. Play with Python**


**SunFounder PiCar-X Kit**


4. Remove the microSD card and insert it into the slot on the underside of your Raspberry Pi. Your Raspberry Pi
is now ready to boot with the new OS!


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


**2.1. 1. Quick Guide on Python** **23**


**SunFounder PiCar-X Kit**


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!


**2.1.3 Power Supply for Raspberry Pi (Important)**


**Charge**


Insert the battery cable. Next, insert the USB-C cable to charge the battery. You will need to provide your own charger;
we recommend a 5V 3A charger, or your commonly used smartphone charger will suffice.


**Note:** Connect an external Type-C power source to the Type-C port on the robot hat; it will immediately start charging
the battery, and a red indicator light will illuminate.When the battery is fully charged, the red light will automatically
turn off.


**24** **Chapter 2. Play with Python**


**SunFounder PiCar-X Kit**


**Power ON**


Turn on the power switch. The Power indicator light and the battery level indicator light will illuminate.


Wait for a few seconds, and you will hear a slight beep, indicating that the Raspberry Pi has successfully booted.


**Note:** If both battery level indicator lights are off, please charge the battery. When you need extended programming
or debugging sessions, you can keep the Raspberry Pi operational by inserting the USB-C cable to charge the battery
simultaneously.


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!


**2.1. 1. Quick Guide on Python** **25**


**SunFounder PiCar-X Kit**


**2.1.4 Set Up Your Raspberry Pi**


To begin programming and controlling your Raspberry Pi, you first need to access it. This guide describes two common
methods:


  - Using a monitor, keyboard, and mouse


  - Setting up a headless (no-screen) connection for remote access


**Note:** The Raspberry Pi Zero 2W installed on the robot is not easy to connect to a screen. We recommend using the
**headless setup** method.


**If You Have a Screen**


**Required Components**


  - Raspberry Pi


  - Official Power Supply


  - MicroSD Card


  - HDMI Cable (For Raspberry Pi 4/5, use **HDMI0**, the port nearest the power connector.)


  - Monitor


  - Keyboard and Mouse


**Steps**


1. Insert the microSD card into your Raspberry Pi.


2. Connect the keyboard, mouse, and monitor.


3. Power on your Raspberry Pi.


4. After booting, the Raspberry Pi OS desktop will appear.


**26** **Chapter 2. Play with Python**


**SunFounder PiCar-X Kit**


5. Open a **Terminal** to enter commands.


**2.1. 1. Quick Guide on Python** **27**


**SunFounder PiCar-X Kit**


**If You Have No Screen (Headless)**


Without a monitor, you can configure and log in to your Raspberry Pi remotely. This is the most convenient method
for most users.


**Required Components**


  - Raspberry Pi


  - Official Power Supply


  - MicroSD Card


  - A computer on the same network


**Tips**


  - Make sure you have completed all settings described in _3. OS Customization Settings_ when installing the system
with Raspberry Pi Imager.


  - Ensure that your Raspberry Pi and your computer are on the same local network.


  - For best stability, use Ethernet if available.


**Connect via SSH**


1. Open a terminal on your computer (Windows: **PowerShell** ; macOS/Linux: **Terminal** ) and connect to your
Raspberry Pi:





2. Alternatively, locate your Pi’s IP address from your router’s DHCP list and connect with:





3. On first login, type `yes` to confirm the SSH certificate.


4. Enter the password you configured in Raspberry Pi Imager. (Nothing appears while typing—this is normal.)


5. After login, you now have full command-line access.


**28** **Chapter 2. Play with Python**


**SunFounder PiCar-X Kit**


**Troubleshooting**


   - **ssh: Could not resolve hostname ...**


**–** Make sure the hostname is correct.


**–** Try connecting using the Pi’s IP address.


   - **The term ‘ssh’ is not recognized... (Windows)**


**–** OpenSSH is not installed. Install it manually or use a third-party SSH client.


**–** See _Install OpenSSH via PowerShell_ or _PuTTY_ .


   - **Permission denied (publickey,password)**


**–** Ensure you are using the username and password created in Raspberry Pi Imager.


   - **Connection refused**


**–** Wait 1–2 minutes after powering on.


**–** Confirm that SSH was enabled in Raspberry Pi Imager.


**Graphical Remote Access Options**


If you prefer a graphical interface:


   - _Remote Desktop_ : Enable **VNC (Virtual Network Computing)** for a full desktop experience on your Pi.


  - : Use Raspberry Pi Connect for secure remote access from anywhere, directly in a browser.


Now you can control your Raspberry Pi without a monitor, either through SSH for command-line operations, or with
VNC / Raspberry Pi Connect for a graphical desktop experience.


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**2.1. 1. Quick Guide on Python** **29**


**SunFounder PiCar-X Kit**


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!


**2.1.5 Install All the Modules (Important)**


1. **Prepare the system**


Make sure your Raspberry Pi is connected to the Internet, then update the system:





**Note:** If you are using Raspberry Pi OS Lite, install the required Python 3 packages first:

```
 sudo apt install git python3-pip python3-setuptools python3-smbus

```

2. **Install robot-hat**


Download and install the `robot-hat` module:





3. **Install vilib**


Download and install the `vilib` module:





4. **Install picar-x**


Download and install the `picar-x` module:





This step may take a little while. Please be patient.


**30** **Chapter 2. Play with Python**


**SunFounder PiCar-X Kit**


5. **Enable sound (I2S amplifier)**


To enable audio output, run the `i2samp.sh` script to install the required I2S amplifier components:





Follow the on-screen prompts by typing `y` and pressing Enter to continue, run `/dev/zero` in the background,
and restart the Picar-X.


**Note:** If there is no sound after restarting, try running the `i2samp.sh` script several times.


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!


**2.1.6 Servo Adjust(Important)**


**Note:** If your Robot HAT is version V44 or higher (with the speaker located at the top of the board) and includes an
onboard **Zero** button, you can skip this step and simply press the **Zero** button to activate the servo zeroing program.


**2.1. 1. Quick Guide on Python** **31**


**SunFounder PiCar-X Kit**


The angle range of the servo is -90~90, but the angle set at the factory is random, maybe 0°, maybe 45°; if we assemble
it with such an angle directly, it will lead to a chaotic state after the robot runs the code, or worse, it will cause the servo
to block and burn out.


So here we need to set all the servo angles to 0° and then install them, so that the servo angle is in the middle, no matter
which direction to turn.


1. To ensure that the servo has been properly set to 0°, first insert the servo arm into the servo shaft and then gently
rotate the rocker arm to a different angle. This servo arm is just to allow you to clearly see that the servo is
rotating.


2. Now, run `servo_zeroing.py` in the `example/` folder.





**32** **Chapter 2. Play with Python**


**SunFounder PiCar-X Kit**


3. Next, plug the servo cable into the P11 port as follows, at the same time you will see the servo arm rotate to a
position(This is the 0° position, which is a random location and may not be vertical or parallel.).

```
     python/img/Z_P11.JPG

```

4. Now, remove the servo arm, ensuring the servo wire remains connected, and do not turn off the power. Then
continue the assembly following the paper instructions.


**Note:**


  - Do not unplug this servo cable before fixing it with the servo screw, you can unplug it after fixing it.


  - Do not rotate the servo while it is powered on to avoid damage; if the servo shaft is not inserted at the right angle,
pull the servo out and reinsert it.


  - Before assembling each servo, you need to plug the servo cable into P11 and turn on the power to set its angle to
0°.

### **2.2 2. Basic Movement**


After assembling your PiCar-X, start with simple movement programs. You will learn how to control the motors, drive
forward/backward, turn, and use basic sensors for avoiding obstacles or following lines.


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!


**2.2. 2. Basic Movement** **33**


**SunFounder PiCar-X Kit**


**2.2.1 1. Calibrating the PiCar-X**


**Calibrate Motors & Servo**


Some servo angles may be slightly tilted due to possible deviations during PiCar-X installation or limitations of the
servos themselves, so you can calibrate them.


Of course, you can skip this chapter if you think the assembly is perfect and doesn’t require calibration.


1. Run the `calibration.py` .





2. After running the code, you will see the following interface displayed in the terminal.


3. The `R` key is used to test if the 3 servos are working properly.


4. Press the number key `1` to select the front wheel servo, and then press the `W/S` key to let the front wheel looks as
forward as possible without skewing left and right.


**34** **Chapter 2. Play with Python**


**SunFounder PiCar-X Kit**


5. Press the number key `2` to select the **Pan servo**, then press the `W/S` key to make the pan/tilt platform look straight
ahead and not tilt left or right.


6. Press the number key `3` to select the **tilt servo**, then press the `W/S` key to make the pan/tilt platform look straight
ahead and not tilt up and down.


**2.2. 2. Basic Movement** **35**


**SunFounder PiCar-X Kit**


7. Since the wiring of the motors may be reversed during installation, you can press `E` to test whether the car can
move forward normally. If not, use the number keys `4` and `5` to select the left and right motors, then press the `Q`
key to calibrate the rotation direction.


8. When the calibration is completed, press the `Spacebar` to save the calibration parameters. There will be a prompt
to enter `y` to confirm, and then press `Ctrl+C` to exit the program to complete the calibration.


**36** **Chapter 2. Play with Python**


**SunFounder PiCar-X Kit**


**Calibrate Grayscale Module**


Due to varying environmental conditions and lighting situations, the preset parameters for the greyscale module might
not be optimal. You can fine-tune these settings through this program to achieve better results.


1. Lay down a strip of black electrical tape, about 15cm long, on a light-colored floor. Center your PiCar-X so that
it straddles the tape. In this setup, the middle sensor of the greyscale module should be directly above the tape,
while the two flanking sensors should hover over the lighter surface.


2. Run the code.





3. After running the code, you will see the following interface displayed in the terminal.


**2.2. 2. Basic Movement** **37**


**SunFounder PiCar-X Kit**


4. Press the “Q” key to initiate the greyscale calibration. You’ll then observe the PiCar-X make minor movements
to both the left and the right. During this process, each of the three sensors should sweep across the electrical
tape at least once.


5. Additionally, you will notice three pairs of significantly different values appearing in the “threshold value” section, while the “line reference” will display two intermediate values, each representing the average of one of
these pairs.


**38** **Chapter 2. Play with Python**


**SunFounder PiCar-X Kit**


6. Next, suspend the PiCar-X in mid-air (or position it over a cliff edge) and press the “E” key. You’ll observe that
the “cliff reference” values are also updated accordingly.


7. Once you’ve verified that all the values are accurate, press the “space” key to save the data. You can then exit the
program by pressing Ctrl+C.


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!


**2.2.2 2. Let PiCar-X Move**


This is the first project, let’s test the basic movement of Picar-X.


**Run the Code**





After running the code, PiCar-X will move forward, turn in an S-shape, stop and shake its head.


**2.2. 2. Basic Movement** **39**


**SunFounder PiCar-X Kit**


**Code**


**Note:** You can **Modify/Reset/Copy/Run/Stop** the code below. But before that, you need to go to source code path
like `picar-x/example` . After modifying the code, you can run it directly to see the effect.



**How it works?**


The basic functionality of PiCar-X is in the `picarx` module, Can be used to control steering gear and wheels, and will
make the PiCar-X move forward, turn in an S-shape, or shake its head.


Now, the libraries to support the basic functionality of PiCar-X are imported. These lines will appear in all the examples


**40** **Chapter 2. Play with Python**


**SunFounder PiCar-X Kit**



that involve PiCar-X movement.





The following function with the `for` loop is then used to make PiCar-X move forward, change directions, and move
the camera’s pan/tilt.






   - `forward()` : Orders the PiCar-X go forward at a given `speed` .


   - `set_dir_servo_angle` : Turns the Steering servo to a specific `angle` .


   - `set_cam_pan_angle` : Turns the Pan servo to a specific `angle` .


   - `set_cam_tilt_angle` : Turns the Tilt servo to a specific `angle` .


**2.2. 2. Basic Movement** **41**


**SunFounder PiCar-X Kit**


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!


**42** **Chapter 2. Play with Python**


**SunFounder PiCar-X Kit**


**2.2.3 3. Keyboard Control**


In this project, we will learn how to use the keyboard to remotely control the PiCar-X. You can control the PiCar-X to
move forward, backward, left, and right.


**Run the Code**





Press keys on keyboard to control PiCar-X!


  - w: Forward


  - a: Turn left


  - s: Backward


  - d: Turn right


  - i: Head up


  - k: Head down


  - j: Turn head left


  - l: Turn head right


  - ctrl + c: Press twice to exit the program


**Code**

```
from picarx import Picarx
from time import sleep
import readchar

manual = '''
Press keys on keyboard to control PiCar-X!
  w: Forward
  a: Turn left
  s: Backward
  d: Turn right
  i: Head up
  k: Head down
  j: Turn head left
  l: Turn head right
  ctrl+c: Quit
'''

def show_info():
  print("\033[H\033[J",end='') # clear terminal windows
  print(manual)

if __name__ == "__main__":
  try:
    pan_angle = 0
    tilt_angle = 0
    px = Picarx()
```

(continues on next page)


**2.2. 2. Basic Movement** **43**


**SunFounder PiCar-X Kit**


(continued from previous page)

```
    show_info()
    while True:
      key = readchar.readkey()
      key = key.lower()
      if key in('wsadikjl'):
        if 'w' == key:
          px.set_dir_servo_angle(0)
          px.forward(80)
        elif 's' == key:
          px.set_dir_servo_angle(0)
          px.backward(80)
        elif 'a' == key:
          px.set_dir_servo_angle(-35)
          px.forward(80)
        elif 'd' == key:
          px.set_dir_servo_angle(35)
          px.forward(80)
        elif 'i' == key:
          tilt_angle+=5
          if tilt_angle>35:
             tilt_angle=35
        elif 'k' == key:
          tilt_angle-=5
          if tilt_angle<-35:
             tilt_angle=-35
        elif 'l' == key:
          pan_angle+=5
          if pan_angle>35:
             pan_angle=35
        elif 'j' == key:
          pan_angle-=5
          if pan_angle<-35:
             pan_angle=-35

        px.set_cam_tilt_angle(tilt_angle)
        px.set_cam_pan_angle(pan_angle)
        show_info()
        sleep(0.5)
        px.forward(0)

      elif key == readchar.key.CTRL_C:
        print("\n Quit")
        break

  finally:
    px.set_cam_tilt_angle(0)
    px.set_cam_pan_angle(0)
    px.set_dir_servo_angle(0)
    px.stop()
    sleep(.2)

```

**How it works?**


**44** **Chapter 2. Play with Python**


**SunFounder PiCar-X Kit**


PiCar-X should take appropriate action based on the keyboard characters read. The `lower()` function converts upper
case characters into lower case characters, so that the letter remains valid regardless of case.



**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!


**2.2.4 4. Obstacle Avoidance**


In this project, PiCar-X will detect obstacles in front of it while moving forward, and when the obstacles are too close,
it will change the direction of moving forward.


**Run the Code**





**2.2. 2. Basic Movement** **45**


**SunFounder PiCar-X Kit**


After running the code, PiCar-X will walk forward.


If it detects that the distance of the obstacle ahead is less than 20cm, it will go backward.


If there is an obstacle within 20 to 40cm, it will turn left.


If there is no obstacle in the direction after turning left or the obstacle distance is greater than 25cm, it will continue to
move forward.


**Code**


**Note:** You can **Modify/Reset/Copy/Run/Stop** the code below. But before that, you need to go to source code path
like `picar-x/example` . After modifying the code, you can run it directly to see the effect.



**How it works?**


  - Importing the Picarx Module and Initializing Constants:


This section of the code imports the `Picarx` class from the `picarx` module, which is essential for controlling the Picarx robot. Constants like `POWER`, `SafeDistance`, and `DangerDistance` are defined,
which will be used later in the script to control the robot’s movement based on distance measurements.


**46** **Chapter 2. Play with Python**


**SunFounder PiCar-X Kit**

```
   from picarx import Picarx
   import time

   POWER = 50
   SafeDistance = 40 # > 40 safe
   DangerDistance = 20 # > 20 && < 40 turn around,
   # < 20 backward

```

- Main Function Definition and Ultrasonic Sensor Reading:


The `main` function is where the Picarx robot is controlled. An instance of `Picarx` is created, which
activates the robot’s functionalities. The code enters an infinite loop, constantly reading the distance
from the ultrasonic sensor. This distance is used to determine the robot’s movement.

```
   def main():
   try:
   px = Picarx()

     while True:
       distance = round(px.ultrasonic.read(), 2)
       # [Rest of the logic]

```

- Movement Logic Based on Distance:


The robot’s movement is controlled based on the `distance` read from the ultrasonic sensor. If
the `distance` is greater than `SafeDistance`, the robot moves forward. If the distance is between
`DangerDistance` and `SafeDistance`, it slightly turns and moves forward. If the `distance` is less
than `DangerDistance`, the robot reverses while turning in the opposite direction.






- Safety and Cleanup with the ‘finally’ Block:


The `try...finally` block ensures safety by stopping the robot’s motion in case of an interruption
or error. This is a crucial part for preventing uncontrollable behavior of the robot.






  - Execution Entry Point:


The standard Python entry point `if __name__ == "__main__":` is used to run the main function
when the script is executed as a standalone program.


**2.2. 2. Basic Movement** **47**


**SunFounder PiCar-X Kit**





In summary, the script uses the Picarx module to control a robot, utilizing an ultrasonic sensor for distance measurement.
The robot’s movement is adapted based on these measurements, ensuring safe operation through careful control and a
safety mechanism in the finally block.


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!


**2.2.5 5. Cliff Detection**


Let us give PiCar-X a little self-protection awareness and let it learn to use its own grayscale module to avoid rushing
down the cliff.


In this example, the car will be dormant. If you push it to a cliff, it will be awakened urgently, then back up.


**Run the Code**





**Code**


**Note:** You can **Modify/Reset/Copy/Run/Stop** the code below. But before that, you need to go to source code path
like `picar-x/example` . After modifying the code, you can run it directly to see the effect.

```
from picarx import Picarx
from time import sleep

px = Picarx()
```

_`# px = Picarx(grayscale_pins=[`_ _'_ _`A0`_ _'_ _`,`_ _'_ _`A1`_ _'_ _`,`_ _'_ _`A2`_ _'_ _`])`_
```
# manual modify reference value
px.set_cliff_reference([200, 200, 200])

last_state = "safe"

if __name__ == '__main__':
  try:
    while True:
```

(continues on next page)


**48** **Chapter 2. Play with Python**


**SunFounder PiCar-X Kit**


(continued from previous page)

```
      gm_val_list = px.get_grayscale_data()
      gm_state = px.get_cliff_status(gm_val_list)
      # print("cliff status is: %s" % gm_state)

      if gm_state is False:
        state = "safe"
        px.stop()
      else:
        state = "danger"
        px.backward(80)
        if last_state == "safe":
          sleep(0.1)

      last_state = state

  except KeyboardInterrupt:
    print("\nKeyboardInterrupt: stop and exit")

  finally:
    px.stop()
    sleep(0.1)

```

**How it works?**


The function to detect the cliff looks like this:


   - `get_grayscale_data()` : This method directly outputs the readings of the three sensors, from right to left. The
brighter the area, the larger the value obtained.


   - `get_cliff_status(gm_val_list)` : This method compares the readings from the three probes and outputs a
result. If the result is true, it is detected that there is a cliff in front of the car.


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!


**2.2. 2. Basic Movement** **49**


**SunFounder PiCar-X Kit**


**2.2.6 6. Line Tracking**


This project will use the Grayscale module to make the PiCar-X move forward along a line. Use dark-colored tape to
make a line as straight as possible, and not too curved. Some experimenting might be needed if the PiCar-X is derailed.


**Run the Code**





After running the code, PiCar-X will move forward along a line.


**Code**


**Note:** You can **Modify/Reset/Copy/Run/Stop** the code below. But before that, you need to go to source code path
like `picar-x/example` . After modifying the code, you can run it directly to see the effect.



**50** **Chapter 2. Play with Python**


**SunFounder PiCar-X Kit**


(continued from previous page)





**How it works?**


This Python script controls a Picarx robot car using grayscale sensors for navigation. Here’s a breakdown of its main
components:


  - Import and Initialization:


The script imports the Picarx class for controlling the robot car and the sleep function from the time
module for adding delays.


An instance of Picarx is created, and there’s a commented line showing an alternative initialization
with specific grayscale sensor pins.

```
     from picarx import Picarx
     from time import sleep

```

(continues on next page)


**2.2. 2. Basic Movement** **51**


**SunFounder PiCar-X Kit**


(continued from previous page)

```
     px = Picarx()

```

  - Configuration and Global Variables:


`current_state`, `px_power`, `offset`, and `last_state` are global variables used to track and control
the car’s movement. `px_power` sets the motor power, and `offset` is used for adjusting the steering
angle.






- `outHandle` Function:


This function is called when the car needs to handle an ‘out of line’ scenario.


It adjusts the car’s direction based on `last_state` and checks the grayscale sensor values to determine
the new state.






- `get_status` Function:


It interprets the grayscale sensor data ( `val_list` ) to determine the car’s navigation state.


The car’s state can be ‘forward’, ‘left’, ‘right’, or ‘stop’, based on which sensor detects the line.










  - Main Loop:


**52** **Chapter 2. Play with Python**


**SunFounder PiCar-X Kit**


The `while True` loop continuously checks the grayscale data and adjusts the car’s movement accordingly.


Depending on the `gm_state`, it sets the steering angle and movement direction.




- Safety and Cleanup:


The `try...finally` block ensures the car stops when the script is interrupted or finished.





In summary, the script uses grayscale sensors to navigate the Picarx robot car. It continuously reads the sensor data
to determine the direction and adjusts the car’s movement and steering accordingly. The outHandle function provides
additional logic for situations where the car needs to adjust its path significantly.

### **2.3 3. Computer Vision**


Give your PiCar-X the ability to see using its camera. This section covers fun vision-based projects such as face
tracking, recording, object interactions, and controlling the car via video or a mobile app.


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


**2.3. 3. Computer Vision** **53**


**SunFounder PiCar-X Kit**


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!


**2.3.1 7. Computer Vision**


This project will officially enter the field of computer vision!


**Run the Code**





**View the Image**


After the code runs, the terminal will display the following prompt:

```
No desktop !
* Serving Flask app "vilib.vilib" (lazy loading)
* Environment: production
WARNING: Do not use the development server in a production environment.
Use a production WSGI server instead.
* Debug mode: off
* Running on http://0.0.0.0:9000/ (Press CTRL+C to quit)

```

Then you can enter `http://<your IP>:9000/mjpg` in the browser to view the video screen. such as: `https://`
```
192.168.18.113:9000/mjpg

```

After the program runs, you will see the following information in the final:


  - Input key to call the function!


  - q: Take photo


  - 1: Color detect : red


  - 2: Color detect : orange


  - 3: Color detect : yellow


  - 4: Color detect : green


  - 5: Color detect : blue


  - 6: Color detect : purple


  - 0: Switch off Color detect


  - r: Scan the QR code


  - f: Switch ON/OFF face detect


  - s: Display detected object information


**54** **Chapter 2. Play with Python**


**SunFounder PiCar-X Kit**


Please follow the prompts to activate the corresponding functions.


   - **Take Photo**


Type `q` in the terminal and press Enter. The picture currently seen by the camera will be saved (if the
color detection function is turned on, the mark box will also appear in the saved picture). You can see
these photos from the `/home/{username}/Pictures/` directory of the Raspberry Pi. You can use
tools such as _FileZilla Software_ to transfer photos to your PC.


   - **Color Detect**


Entering a number between `1~6` will detect one of the colors in “red, orange, yellow, green, blue,
purple”. Enter `0` to turn off color detection.


**Note:** You can download and print the `PDF Color Cards` for color detection.


   - **Face Detect**


Type `f` to turn on face detection.


**2.3. 3. Computer Vision** **55**


**SunFounder PiCar-X Kit**


   - **QR Code Detect**


Enter `r` to open the QR code recognition. No other operations can be performed before the QR code
is recognized. The decoding information of the QR code will be printed in the terminal.


   - **Display Information**


**56** **Chapter 2. Play with Python**


**SunFounder PiCar-X Kit**


Entering `s` will print the information of the face detection (and color detection) target in the terminal.
Including the center coordinates (X, Y) and size (Weight, height) of the measured object.


**Code**

```
from pydoc import text
from vilib import Vilib
from time import sleep, time, strftime, localtime
import threading
import readchar
import os

flag_face = False
flag_color = False
qr_code_flag = False

manual = '''
Input key to call the function!
  q: Take photo
  1: Color detect : red
  2: Color detect : orange
  3: Color detect : yellow
  4: Color detect : green
  5: Color detect : blue
  6: Color detect : purple
  0: Switch off Color detect
  r: Scan the QR code
  f: Switch ON/OFF face detect
  s: Display detected object information
'''

color_list = ['close', 'red', 'orange', 'yellow',
    'green', 'blue', 'purple',
]

def face_detect(flag):
  print("Face Detect:" + str(flag))
  Vilib.face_detect_switch(flag)

def qrcode_detect():
  global qr_code_flag
  if qr_code_flag == True:
    Vilib.qrcode_detect_switch(True)
    print("Waitting for QR code")

  text = None
  while True:
    temp = Vilib.detect_obj_parameter['qr_data']
    if temp != "None" and temp != text:
      text = temp
      print('QR code: %s '%text)
    if qr_code_flag == False:
      break
```

(continues on next page)


**2.3. 3. Computer Vision** **57**


**SunFounder PiCar-X Kit**


(continued from previous page)

```
    sleep(0.5)
  Vilib.qrcode_detect_switch(False)

def take_photo():
  _time = strftime('%Y-%m- %d -%H-%M-%S',localtime(time()))
  name = 'photo_ %s '%_time
  username = os.getlogin()

  path = f"/home/ { username } /Pictures/"
  Vilib.take_photo(name, path)
  print('photo save as %s%s .jpg'%(path,name))

def object_show():
  global flag_color, flag_face

  if flag_color is True:
    if Vilib.detect_obj_parameter['color_n'] == 0:
      print('Color Detect: None')
    else:
      color_coodinate = (Vilib.detect_obj_parameter['color_x'],Vilib.detect_obj_
```

_˓→_ `parameter['color_y'])`
```
      color_size = (Vilib.detect_obj_parameter['color_w'],Vilib.detect_obj_
```

_˓→_ `parameter['color_h'])`
```
      print("[Color Detect] ","Coordinate:",color_coodinate,"Size",color_size)

  if flag_face is True:
    if Vilib.detect_obj_parameter['human_n'] == 0:
      print('Face Detect: None')
    else:
      human_coodinate = (Vilib.detect_obj_parameter['human_x'],Vilib.detect_obj_
```

_˓→_ `parameter['human_y'])`
```
      human_size = (Vilib.detect_obj_parameter['human_w'],Vilib.detect_obj_
```

_˓→_ `parameter['human_h'])`
```
      print("[Face Detect] ","Coordinate:",human_coodinate,"Size",human_size)

def main():
  global flag_face, flag_color, qr_code_flag
  qrcode_thread = None

  Vilib.camera_start(vflip=False,hflip=False)
  Vilib.display(local=True,web=True)
  print(manual)

  while True:
    # readkey
    key = readchar.readkey()
    key = key.lower()
    # take photo
    if key == 'q':

```

(continues on next page)


**58** **Chapter 2. Play with Python**


**SunFounder PiCar-X Kit**


(continued from previous page)



**How it works?**


The first thing you need to pay attention to here is the following function. These two functions allow you to start the
camera.





Functions related to “object detection”:


   - `Vilib.face_detect_switch(True)` : Switch ON/OFF face detection


   - `Vilib.color_detect(color)` : For color detection, only one color detection can be performed at the same
time. The parameters that can be input are: `"red"`, `"orange"`, `"yellow"`, `"green"`, `"blue"`, `"purple"`


   - `Vilib.color_detect_switch(False)` : Switch OFF color detection


**2.3. 3. Computer Vision** **59**


**SunFounder PiCar-X Kit**


   - `Vilib.qrcode_detect_switch(False)` : Switch ON/OFF QR code detection, Returns the decoded data of
the QR code.


   - `Vilib.gesture_detect_switch(False)` : Switch ON/OFF gesture detection


   - `Vilib.traffic_sign_detect_switch(False)` : Switch ON/OFF traffic sign detection


The information detected by the target will be stored in the `detect_obj_parameter = Manager().dict()` dictionary.


In the main program, you can use it like this:

```
Vilib.detect_obj_parameter['color_x']

```

The keys of the dictionary and their uses are shown in the following list:


   - `color_x` : the x value of the center coordinate of the detected color block, the range is 0~320


   - `color_y` : the y value of the center coordinate of the detected color block, the range is 0~240


   - `color_w` : the width of the detected color block, the range is 0~320


   - `color_h` : the height of the detected color block, the range is 0~240


   - `color_n` : the number of detected color patches


   - `human_x` : the x value of the center coordinate of the detected human face, the range is 0~320


   - `human_y` : the y value of the center coordinate of the detected face, the range is 0~240


   - `human_w` : the width of the detected human face, the range is 0~320


   - `human_h` : the height of the detected face, the range is 0~240


   - `human_n` : the number of detected faces


   - `traffic_sign_x` : the center coordinate x value of the detected traffic sign, the range is 0~320


   - `traffic_sign_y` : the center coordinate y value of the detected traffic sign, the range is 0~240


   - `traffic_sign_w` : the width of the detected traffic sign, the range is 0~320


   - `traffic_sign_h` : the height of the detected traffic sign, the range is 0~240


   - `traffic_sign_t` : the content of the detected traffic sign, the value list is _[‘stop’,’right’,’left’,’forward’]_


   - `gesture_x` : The center coordinate x value of the detected gesture, the range is 0~320


   - `gesture_y` : The center coordinate y value of the detected gesture, the range is 0~240


   - `gesture_w` : The width of the detected gesture, the range is 0~320


   - `gesture_h` : The height of the detected gesture, the range is 0~240


   - `gesture_t` : The content of the detected gesture, the value list is _[“paper”,”scissor”,”rock”]_


   - `qr_date` : the content of the QR code being detected


   - `qr_x` : the center coordinate x value of the QR code to be detected, the range is 0~320


   - `qr_y` : the center coordinate y value of the QR code to be detected, the range is 0~240


   - `qr_w` : the width of the QR code to be detected, the range is 0~320


   - `qr_h` : the height of the QR code to be detected, the range is 0~320


**60** **Chapter 2. Play with Python**


**SunFounder PiCar-X Kit**


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!


**2.3.2 8. Stare at You**


This project is also based on the _7. Computer Vision_ project, with the addition of face detection algorithms.


When you appear in front of the camera, it will recognize your face and adjust its gimbal to keep your face in the center
of the frame.


You can view the screen at `http://<your IP>:9000/mjpg` .


**Run the Code**





When the code is run, the car’s camera will always be staring at your face.


**Code**

```
from picarx import Picarx
from time import sleep
from vilib import Vilib

px = Picarx()

def clamp_number(num,a,b):
  return max(min(num, max(a, b)), min(a, b))

def main():
  Vilib.camera_start()
  Vilib.display()
  Vilib.face_detect_switch(True)
  x_angle =0
  y_angle =0
  while True:
    if Vilib.detect_obj_parameter['human_n']!=0:
      coordinate_x = Vilib.detect_obj_parameter['human_x']
      coordinate_y = Vilib.detect_obj_parameter['human_y']

      # change the pan-tilt angle for track the object
```

(continues on next page)


**2.3. 3. Computer Vision** **61**


**SunFounder PiCar-X Kit**


(continued from previous page)

```
      x_angle +=(coordinate_x*10/640)-5
      x_angle = clamp_number(x_angle,-35,35)
      px.set_cam_pan_angle(x_angle)

      y_angle -=(coordinate_y*10/480)-5
      y_angle = clamp_number(y_angle,-35,35)
      px.set_cam_tilt_angle(y_angle)

      sleep(0.05)

    else :
      pass
      sleep(0.05)

if __name__ == "__main__":
  try:
  main()

  finally:
    px.stop()
    print("stop and exit")
    sleep(0.1)

```

**How it works?**


These lines of code in `while True` make the camera follow the face.



1. Check if there is a detected human face

```
     Vilib.detect_obj_parameter['human_n'] != 0

```

2. If a human face is detected, obtain the coordinates ( `coordinate_x` and `coordinate_y` ) of the detected face.


3. Calculate new pan and tilt angles ( `x_angle` and `y_angle` ) based on the detected face’s position and adjust them
to follow the face.


4. Limit the pan and tilt angles within the specified range using the `clamp_number` function.


5. Set the camera’s pan and tilt angles using `px.set_cam_pan_angle()` and `px.set_cam_tilt_angle()` .


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!


**62** **Chapter 2. Play with Python**


**SunFounder PiCar-X Kit**


Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!


**2.3.3 9. Record Video**


This example will guide you how to use the recording function.


**Run the Code**





After the code runs, you can enter `http://<your IP>:9000/mjpg` in the browser to view the video screen. such as:
```
http://192.168.18.113:9000/mjpg

```

Recording can be stopped or started by pressing the keys on the keyboard.


  - Press `q` to begin recording or pause/continue, `e` to stop recording or save.


  - If you want to exit the program, press `ctrl+c` .


**Code**





**2.3. 3. Computer Vision** **63**


**SunFounder PiCar-X Kit**


(continued from previous page)

```
def main():
  rec_flag = 'stop' # start,pause,stop
  vname = None
  username = os.getlogin()

  Vilib.rec_video_set["path"] = f"/home/ { username } /Videos/" # set path

  Vilib.camera_start(vflip=False,hflip=False)
  Vilib.display(local=True,web=True)
  sleep(0.8) # wait for startup

  print(manual)
  while True:
    # read keyboard
    key = readchar.readkey()
    key = key.lower()
    # start,pause
    if key == 'q':
      key = None
      if rec_flag == 'stop':
        rec_flag = 'start'
        # set name
        vname = strftime("%Y-%m- %d -%H.%M.%S", localtime())
        Vilib.rec_video_set["name"] = vname
        # start record
        Vilib.rec_video_run()
        Vilib.rec_video_start()
        print_overwrite('rec start ...')
      elif rec_flag == 'start':
        rec_flag = 'pause'
        Vilib.rec_video_pause()
        print_overwrite('pause')
      elif rec_flag == 'pause':
        rec_flag = 'start'
        Vilib.rec_video_start()
        print_overwrite('continue')
    # stop
    elif key == 'e' and rec_flag != 'stop':
      key = None
      rec_flag = 'stop'
      Vilib.rec_video_stop()
      print_overwrite("The video saved as %s%s .avi"%(Vilib.rec_video_set["path"],
```

_˓→_ `vname),end='\n')`
```
    # quit
    elif key == readchar.key.CTRL_C:
      Vilib.camera_close()
      print('\nquit')
      break

    sleep(0.1)

if __name__ == "__main__":

```

(continues on next page)


**64** **Chapter 2. Play with Python**


**SunFounder PiCar-X Kit**


(continued from previous page)

```
  main()

```

**How it works?**


Functions related to recording include the following:


   - `Vilib.rec_video_run(video_name)` : Started the thread to record the video. `video_name` is the name of
the video file, it should be a string.


   - `Vilib.rec_video_start()` : Start or continue video recording.


   - `Vilib.rec_video_pause()` : Pause recording.


   - `Vilib.rec_video_stop()` : Stop recording.


`Vilib.rec_video_set["path"] = f"/home/{username}/Videos/"` sets the storage location of video files.


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!


**2.3.4 10. Bull Fight**


Make PiCar-X an angry bull! Use its camera to track and rush the red cloth!


**Run the Code**





**View the Image**


After the code runs, the terminal will display the following prompt:

```
No desktop !
* Serving Flask app "vilib.vilib" (lazy loading)
* Environment: production
WARNING: Do not use the development server in a production environment.
Use a production WSGI server instead.
* Debug mode: off
* Running on http://0.0.0.0:9000/ (Press CTRL+C to quit)

```

Then you can enter `http://<your IP>:9000/mjpg` in the browser to view the video screen. such as: `https://`
```
192.168.18.113:9000/mjpg

```

**2.3. 3. Computer Vision** **65**


**SunFounder PiCar-X Kit**


**Code**


**Note:** You can **Modify/Reset/Copy/Run/Stop** the code below. But before that, you need to go to source code path
like `picar-x\examples` . After modifying the code, you can run it directly to see the effect.



**66** **Chapter 2. Play with Python**


**SunFounder PiCar-X Kit**


(continued from previous page)







**How it works?**


You need to pay attention to the following three parts of this example:


1. Define the main function:


     - Start the camera using `Vilib.camera_start()` .


     - Display the camera feed using `Vilib.display()` .


     - Enable color detection and specify the target color as “red” using `Vilib.color_detect("red")` .


     - Initialize variables: `speed` for car movement speed, `dir_angle` for the direction angle of the car’s movement, `x_angle` for the camera’s pan angle, and `y_angle` for the camera’s tilt angle.


2. Enter a continuous loop (while True) to track the red-colored object:


     - Check if there is a detected red-colored object ( `Vilib.detect_obj_parameter['color_n'] != 0` ).


     - If a red-colored object is detected, obtain its coordinates ( `coordinate_x` and `coordinate_y` ).


     - Calculate new pan and tilt angles ( `x_angle` and `y_angle` ) based on the detected object’s position and
adjust them to track the object.


     - Limit the pan and tilt angles within the specified range using the `clamp_number` function.


     - Set the camera’s pan and tilt angles using `px.set_cam_pan_angle()` and `px.set_cam_tilt_angle()`
to keep the object in view.


3. Control the car’s movement based on the difference between dir_angle and `x_angle` :


     - If `dir_angle` is greater than `x_angle`, decrement `dir_angle` by 1 to gradually change the direction angle.


     - If `dir_angle` is less than `x_angle`, increment `dir_angle` by 1.


     - Set the direction servo angle using `px.set_dir_servo_angle()` to steer the car’s wheels accordingly.


     - Move the car forward at the specified speed using `px.forward(speed)` .


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


**2.3. 3. Computer Vision** **67**


**SunFounder PiCar-X Kit**


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!


**2.3.5 11. Video Car**


This program will provide a First Person View from the PiCar-X! Use the keyboards WSAD keys to control the direction
of movement, and the O and P to adjust the speed.


**Run the Code**





Once the code is running, you can see what PiCar-X is shooting and control it by pressing the following keys.


  - O: speed up


  - P: speed down


  - W: forward


  - S: backward


  - A: turn left


  - D: turn right


  - F: stop


  - T: take photo


  - Ctrl+C: quit


**View the Image**


After the code runs, the terminal will display the following prompt:

```
No desktop !
* Serving Flask app "vilib.vilib" (lazy loading)
* Environment: production
WARNING: Do not use the development server in a production environment.
Use a production WSGI server instead.
* Debug mode: off
* Running on http://0.0.0.0:9000/ (Press CTRL+C to quit)

```

Then you can enter `http://<your IP>:9000/mjpg` in the browser to view the video screen. such as: `https://`
```
192.168.18.113:9000/mjpg

```

**code**


**68** **Chapter 2. Play with Python**


**SunFounder PiCar-X Kit**



**2.3. 3. Computer Vision** **69**


**SunFounder PiCar-X Kit**


(continued from previous page)

```
      px.set_dir_servo_angle(-30)
      px.forward(speed)
    elif operate == 'turn right':
      px.set_dir_servo_angle(30)
      px.forward(speed)

def main():
  speed = 0
  status = 'stop'

  Vilib.camera_start(vflip=False,hflip=False)
  Vilib.display(local=True,web=True)
  sleep(2) # wait for startup
  print(manual)

  while True:
    print("\rstatus: %s, speed: %s "%(status, speed), end='', flush=True)
    # readkey
    key = readchar.readkey().lower()
    # operation
    if key in ('wsadfop'):
      # throttle
      if key == 'o':
        if speed <=90:
          speed += 10
      elif key == 'p':
        if speed >=10:
          speed -= 10
        if speed == 0:
          status = 'stop'
      # direction
      elif key in ('wsad'):
        if speed == 0:
           speed = 10
        if key == 'w':
           # Speed limit when reversing,avoid instantaneous current too large
           if status != 'forward' and speed > 60:
             speed = 60
           status = 'forward'
        elif key == 'a':
           status = 'turn left'
        elif key == 's':
           if status != 'backward' and speed > 60: # Speed limit when reversing
             speed = 60
           status = 'backward'
        elif key == 'd':
           status = 'turn right'
      # stop
      elif key == 'f':
        status = 'stop'

```

(continues on next page)


**70** **Chapter 2. Play with Python**


**SunFounder PiCar-X Kit**


(continued from previous page)

```
      # move
      move(status, speed)
    # take photo
    elif key == 't':
      take_photo()
    # quit
    elif key == readchar.key.CTRL_C:
      print('\nquit ...')
      px.stop()
      Vilib.camera_close()
      break

    sleep(0.1)

if __name__ == "__main__":
  try:
    main()
  except Exception as e:
    print("error: %s "%e)
  finally:
    px.stop()
    Vilib.camera_close()

```

**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!


**2.3.6 12. Controlled by the APP**


The SunFounder controller is used to control Raspberry Pi/Pico based robots.


The APP integrates Button, Switch, Joystick, D-pad, Slider and Throttle Slider widgets; Digital Display, Ultrasonic
Radar, Grayscale Detection and Speedometer input widgets.


There are 17 areas A-Q, where you can place different widgets to customize your own controller.


In addition, this application provides a live video streaming service.


Let’s customize a PiCar-X controller using this app.


**How to do?**


**2.3. 3. Computer Vision** **71**


**SunFounder PiCar-X Kit**


1. Install the `sunfounder-controller` module.


The `robot-hat`, `vilib`, and `picar-x` modules need to be installed first, for details see: _Install All_
_the Modules (Important)_ .





2. Run the code.





[3. Install SunFounder Controller from](https://docs.sunfounder.com/projects/sf-controller/en/latest/) **APP Store(iOS)** or **Google Play(Android)** .


4. Open and create a new controller.


Create a new controller by clicking on the + sign in the SunFounder Controller APP.


There are preset controllers for some products in the Preset section, which you can use as needed.
Here, we select **PiCar-X** .


**72** **Chapter 2. Play with Python**


**SunFounder PiCar-X Kit**


5. Connect to PiCar-x.


When you click the **Connect** button, it will automatically search for robots nearby. Its name is defined
in `picarx_control.py` and it must be running at all times.


Once you click on the product name, the message “Connected Successfully” will appear and the
product name will appear in the upper right corner.


**2.3. 3. Computer Vision** **73**


**SunFounder PiCar-X Kit**


**Note:**


       - You need to make sure that your mobile device is connected to the same LAN as PiCar-X.


        - If it doesn’t search automatically, you can also manually enter the IP to connect.


6. Run this controller.


Click the **Run** button to start the controller, you will see the footage of the car shooting, and now you
can control your PiCar-X with these widgets.


**74** **Chapter 2. Play with Python**


**SunFounder PiCar-X Kit**


Here are the functions of the widgets.


        - **A** : Show the current speed of the car.


        - **E** : turn on the obstacle avoidance function.


        - **I** : turn on the line following function.


        - **J** : voice recognition, press and hold this widget to start speaking, and it will show the recognized
voice when you release it. We have set `forward`, `backard`, `left` and `right` 4 commands in the
code to control the car.


        - **K** : Control forward, backward, left, and right motions of the car.


        - **Q** : turn the head(Camera) up, down, left and right.


        - **N** : Turn on the color recognition function.


        - **O** : Turn on the face recognition function.


        - **P** : Turn on the object recognition function, it can recognize nearly 90 kinds of objects, for the list
[of models, please refer to: https://github.com/sunfounder/vilib/blob/master/workspace/coco_](https://github.com/sunfounder/vilib/blob/master/workspace/coco_labels.txt)
[labels.txt.](https://github.com/sunfounder/vilib/blob/master/workspace/coco_labels.txt)


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


**2.3. 3. Computer Vision** **75**


**SunFounder PiCar-X Kit**


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!


**76** **Chapter 2. Play with Python**


**CHAPTER**

### **THREE** **THINK · TALK · DRIVE — AI-POWERED WITH MULTI-LLMS**


Go beyond movement and vision by adding **speech** and **AI** . Here you will explore text-to-speech (TTS), speech-to-text
(STT), and large language models (LLMs) to make your PiCar-X talk, listen, and even chat with you like a smart robot.


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!

### **3.1 13. Play Music and Sound Effects**


In this project, you will learn how to make the PiCar-X play background music or sound effects. You can also play
music files that you have stored.


**Before You Start**


Make sure you‘ve completed:


   - _Install All the Modules (Important)_   - Install `robot-hat`, `vilib`, `picar-x` modules, then run the script
`i2samp.sh` .


**Run the Code**





After the code runs, please operate according to the prompt that printed on the terminal.


Input key to call the function!


  - space: Play sound effect (Car horn)


  - c: Play sound effect with threads


  - q: Play/Stop Music



**77**


**SunFounder PiCar-X Kit**


**Code**



**How it works?**


Functions related to background music include these:


   - `music = Music()` : Declare the object.


   - `music.music_set_volume(20)` : Set the volume, the range is 0~100.


   - `music.music_play('../musics/slow-trail-Ahjay_Stelino.mp3')` : Play music files, here is the **slow-**
**trail-Ahjay_Stelino.mp3** file under the `../musics` path.


   - `music.music_stop()` : Stop playing background music.


**78** **Chapter 3. Think · Talk · Drive — AI-Powered with Multi-LLMs**


**SunFounder PiCar-X Kit**


**Note:** You can add different sound effects or music to `musics` or `sounds` folder via _FileZilla Software_ .


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!

### **3.2 14. Voice Prompt Car with Espeak and Pico2Wave**


In this lesson, we’ll use two built-in text-to-speech (TTS) engines on Raspberry Pi — **Espeak** and **Pico2Wave** - to
make the PiCar-X talk.


These two engines are both simple and run offline, but they sound quite different:


   - **Espeak** : very lightweight and fast, but the voice is robotic. You can adjust speed, pitch, and volume.


   - **Pico2Wave** : produces a smoother and more natural voice than Espeak, but has fewer options to configure.


You’ll hear the difference in **voice quality** and **features**, and then build a “voice prompt car” that announces its actions
before moving.


**3.2.1 Before You Start**


Make sure you‘ve completed:


   - _Install All the Modules (Important)_   - Install `robot-hat`, `vilib`, `picar-x` modules, then run the script
`i2samp.sh` .


**3.2.2 1. Testing Espeak**


Espeak is a lightweight TTS engine included in Raspberry Pi OS. Its voice sounds robotic, but it is highly configurable:
you can adjust volume, pitch, speed, and more.


**Steps to try it out** :


  - Create a new file with the command:






  - Then copy the example code into it. Press `Ctrl+X`, then `Y`, and finally `Enter` to save and exit.


**3.2. 14. Voice Prompt Car with Espeak and Pico2Wave** **79**


**SunFounder PiCar-X Kit**




  - Run the program with:

```
   sudo python3 test_tts_espeak.py

```

  - You should hear the PiCar-X say: “Hello! I’m Espeak TTS.”


  - Uncomment the voice tuning lines in the code to experiment with how `amp`, `speed`, `gap`, and `pitch` affect the
sound.


**3.2.3 2. Testing Pico2Wave**


Pico2Wave produces a more natural, human-like voice than Espeak. It’s simpler to use but less flexible — you can only
change the language, not the pitch or speed.


**Steps to try it out** :


  - Create a new file with the command:






  - Then copy the example code into it. Press `Ctrl+X`, then `Y`, and finally `Enter` to save and exit.

```
   from picarx.tts import Pico2Wave

   tts = Pico2Wave()

   tts.set_lang('en-US') # en-US, en-GB, de-DE, es-ES, fr-FR, it-IT

   # Quick hello (sanity check)
   tts.say("Hello! I'm Pico2Wave TTS.")

```

  - Run the program with:

```
   sudo python3 test_tts_pico2wave.py

```

  - You should hear the PiCar-X say: “Hello! I’m Pico2Wave TTS.”


  - Try switching the language (for example, `es-ES` for Spanish) and listen to the difference.


**80** **Chapter 3. Think · Talk · Drive — AI-Powered with Multi-LLMs**


**SunFounder PiCar-X Kit**


**3.2.4 3. Voice Prompt Car**


Now let’s combine **Pico2Wave** or **Espeak** with PiCar-X driving code to create a “voice prompt car”: before every
action, the car will announce what it’s about to do.


**Run the Code**





Run this code and you’ll see your PiCar-X drive forward, backward, and turn, each time announcing its move first. This
makes your car safer, friendlier, and more interactive.


**Code**



**3.2. 14. Voice Prompt Car with Espeak and Pico2Wave** **81**


**SunFounder PiCar-X Kit**


(continued from previous page)



**3.2.5 Troubleshooting**


   - **No sound when running Espeak or Pico2Wave**


**–** Check that your speakers/headphones are connected and volume is not muted.


**–** Run a quick test in terminal:





If you hear nothing, the issue is with audio output, not your Python code.


- **Espeak voice sounds too fast or too robotic**


**–** Try adjusting the parameters in your code:






   - **Permission denied when running code**


**–** Try running with `sudo` :

```
     sudo python3 test_tts_espeak.py

```

**3.2.6 Comparison: Espeak vs Pico2Wave**


**82** **Chapter 3. Think · Talk · Drive — AI-Powered with Multi-LLMs**


**SunFounder PiCar-X Kit**


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!

### **3.3 15. AI Storytelling Robot with Piper and OpenAI**


In the previous lesson, we tried two built-in TTS engines on Raspberry Pi ( **Espeak** and **Pico2Wave** ). Now let’s explore
two more powerful options: **Piper** (offline, neural network-based) and **OpenAI TTS** (online, cloud-based).


   - **Piper** : a local TTS engine that runs offline on Raspberry Pi.


   - **OpenAI TTS** : an online service that provides very natural, human-like voices.


At the end, your PiCar-X will drive around and tell jokes like a little storyteller.


**3.3.1 Before You Start**


Make sure you‘ve completed:


   - _Install All the Modules (Important)_   - Install `robot-hat`, `vilib`, `picar-x` modules, then run the script
`i2samp.sh` .


**3.3.2 1. Testing Piper**


**Steps to try it out** :


1. Create a new file:





2. Copy the example code below into the file. Press `Ctrl+X`, then `Y`, and finally `Enter` to save and exit.

```
   from picarx.tts import Piper

   tts = Piper()

   # List supported languages
```

(continues on next page)


**3.3. 15. AI Storytelling Robot with Piper and OpenAI** **83**


**SunFounder PiCar-X Kit**


(continued from previous page)

```
   print(tts.available_countrys())

   # List models for English (en_us)
   print(tts.available_models('en_us'))

   # Set a voice model (auto-download if not already present)
   tts.set_model("en_US-amy-low")

   # Say something
   tts.say("Hello! I'm Piper TTS.")

```

      - `available_countrys()` : print supported languages.


      - `available_models()` : list available models for that language.


      - `set_model()` : set the voice model (downloads automatically if missing).


      - `say()` : convert text to speech and play it.


3. Run the program:

```
   sudo python3 test_tts_piper.py

```

4. The first time you run it, the selected voice model will be downloaded automatically.


     - You should then hear the PiCar-X say: `Hello! I'm Piper TTS.`


     - You can change to another language model by calling `set_model()` with a different name.


**3.3.3 2. Testing OpenAI TTS**


**Get and save your API Key**


1. Go to and log in. On the **API keys** page, click **Create new secret key** .


**84** **Chapter 3. Think · Talk · Drive — AI-Powered with Multi-LLMs**


**SunFounder PiCar-X Kit**


2. Fill in the details (Owner, Name, Project, and permissions if needed), then click **Create secret key** .


**3.3. 15. AI Storytelling Robot with Piper and OpenAI** **85**


**SunFounder PiCar-X Kit**


3. Once the key is created, copy it right away — you won’t be able to see it again. If you lose it, you must generate
a new one.


**86** **Chapter 3. Think · Talk · Drive — AI-Powered with Multi-LLMs**


**SunFounder PiCar-X Kit**


4. In your project folder (for example: `/picar-x/example` ), create a file called `secret.py` :





5. Paste your key into the file like this:





**Write and Run a Test Program**


1. Create a new file:





2. Copy the example code below into the file. Press `Ctrl+X`, then `Y`, and finally `Enter` to save and exit.

```
   from picarx.tts import OpenAI_TTS
   from secret import OPENAI_API_KEY # or use the try/except version shown above

   # Initialize OpenAI TTS
   tts = OpenAI_TTS(api_key=OPENAI_API_KEY)
   tts.set_model('gpt-4o-mini-tts') # low-latency TTS model
   tts.set_voice('alloy') # pick a voice

   # Quick hello (sanity check)
   tts.say("Hello! I'm OpenAI TTS.")

```

**3.3. 15. AI Storytelling Robot with Piper and OpenAI** **87**


**SunFounder PiCar-X Kit**


3. Run the program:

```
   sudo python3 test_tts_openai.py

```

4. You should hear the PiCar-X say:

```
   Hello! I'm OpenAI TTS.

```

**3.3.4 3. Storytelling Robot**


Now that we have tested both **Piper** and **OpenAI TTS**, let’s use them in a real project: a **storytelling robot car** that
drives around while telling jokes.


In this program, the PiCar-X will:


  - Greet you with TTS when it starts.


  - Move forward and tell a first joke.


  - Move forward again and tell a second joke.


  - Finally drive backward, return “home,” and say goodbye.


It’s like having a little robot storyteller on wheels!


**Run the code**





**Code**

```
from picarx import Picarx
import time

# === TTS Configuration ===
# Default: Piper
from picarx.tts import Piper
tts = Piper()
tts.set_model("en_US-amy-low") # use the voice model you installed

# Optional: switch to OpenAI TTS
# from picarx.tts import OpenAI_TTS
# from secret import OPENAI_API_KEY
# tts = OpenAI_TTS(api_key=OPENAI_API_KEY)
# tts.set_model("gpt-4o-mini-tts") # low-latency TTS model
# tts.set_voice("alloy") # choose a voice

# === PiCar-X Setup ===
px = Picarx()

# Quick hello (sanity check)
tts.say("Hello! I'm PiCar-X speaking with Piper.")

def main():
  try:
    # Leg 1
```

(continues on next page)


**88** **Chapter 3. Think · Talk · Drive — AI-Powered with Multi-LLMs**


**SunFounder PiCar-X Kit**


(continued from previous page)

```
    px.forward(30)
    time.sleep(3)
    px.stop()
    tts.say("Why can't your nose be twelve inches long? Because then it would be a␣
```

_˓→_ `foot!")`

```
    # Leg 2
    px.forward(30)
    time.sleep(3)
    px.stop()
    tts.say("Why did the cow go to outer space? To see the moooon!")

    # Wrap-up
    tts.say("That's all for today. Goodbye, let's go home and sleep.")
    px.backward(30)
    time.sleep(6)
    px.stop()

  except KeyboardInterrupt:
    px.stop()
  finally:
    px.stop()
    px.set_dir_servo_angle(0)

if __name__ == "__main__":
  main()

```

**3.3.5 Troubleshooting**


   - **No module named ‘secret’**


This means `secret.py` is not in the same folder as your Python file. Move `secret.py` into the same directory
where you run the script, e.g.:






   - **OpenAI: Invalid API key / 401**


**–** Check that you pasted the full key (starts with `sk-` ) and there are no extra spaces/newlines.


**–** Ensure your code imports it correctly:

```
     from secret import OPENAI_API_KEY

```

**–** Confirm network access on your Pi (try `ping api.openai.com` ).


   - **OpenAI: Quota exceeded / billing error**


**–** You may need to add billing or increase quota in the OpenAI dashboard.


**–** Try again after resolving the account/billing issue.


   - **Piper: tts.say() runs but no sound**


**3.3. 15. AI Storytelling Robot with Piper and OpenAI** **89**


**SunFounder PiCar-X Kit**


**–** Make sure a voice model is actually present:

```
     ls ~/.local/share/piper/voices

```

**–** Confirm your model name matches exactly in code:

```
     tts.set_model("en_US-amy-low")

```

**–** Check the audio output device/volume on your Pi ( `alsamixer` ), and that speakers are connected and powered.


   - **ALSA / sound device errors (e.g., “Audio device busy” or “No such file or directory”)**


**–** Close other programs using audio.


**–** Reboot the Pi if the device stays busy.


**–** For HDMI vs. headphone jack output, select the correct device in Raspberry Pi OS audio settings.


   - **Permission denied when running Python**


**–** Try with `sudo` if your environment requires it:

```
     sudo python3 test_tts_piper.py

```

**3.3.6 Comparison of TTS Engines**


Table 1: Feature comparison: Espeak vs Pico2Wave vs Piper vs OpenAI
TTS

































**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


**90** **Chapter 3. Think · Talk · Drive — AI-Powered with Multi-LLMs**


**SunFounder PiCar-X Kit**


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!

### **3.4 16. Voice Controlled Car with Vosk (Offline)**


Vosk is a lightweight speech-to-text (STT) engine that supports many languages and runs fully **offline** on Raspberry
Pi. You only need internet access once to download a language model. After that, everything works without a network
connection.


In this lesson, we will:


  - Check the microphone on Raspberry Pi.


  - Install and test Vosk with a chosen language model.


  - Build a **voice controlled PiCar-X** that listens for a wake word and then responds to commands like **forward**,
**backward**, **left**, and **right** .


**3.4.1 Before You Start**


Make sure you‘ve completed:


   - _Install All the Modules (Important)_   - Install `robot-hat`, `vilib`, `picar-x` modules, then run the script
`i2samp.sh` .


**3.4.2 1. Check Your Microphone**


Before using speech recognition, make sure your USB microphone works correctly.


1. List available recording devices:

```
   arecord -l

```

Look for a line like `card 1:` `...` `device 0` .


2. Record a short sample (replace `1,0` with the numbers you found):

```
   arecord -D plughw:1,0 -f S16_LE -r 16000 -d 3 test.wav

```

     - Example: if your device is `card 2, device 0`, use:

```
   arecord -D plughw:2,0 -f S16_LE -r 16000 -d 3 test.wav

```

3. Play it back to confirm the recording:

```
   aplay test.wav

```

4. Adjust microphone volume if needed:


**3.4. 16. Voice Controlled Car with Vosk (Offline)** **91**


**SunFounder PiCar-X Kit**

```
   alsamixer

```

     - Press **F6** to select your USB microphone.


     - Find the **Mic** or **Capture** channel.


     - Make sure it is not muted ( **[MM]** means mute, press `M` to unmute _→_ should show **[OO]** ).


     - Use ↑/ ↓arrow keys to change the recording volume.


**3.4.3 2. Test Vosk**


**Steps to try it out** :


1. Create a new file:





2. Copy the example code into it. Press `Ctrl+X`, then `Y`, and `Enter` to save and exit.

```
 from picarx.stt import Vosk

 vosk = Vosk(language="en-us")

 print(vosk.available_languages)

 while True:
   print("Say something")
   result = vosk.listen(stream=False)
   print(result)

```

3. Run the program:

```
 sudo python3 test_stt_vosk.py

```

4. The first time you run this code with a new language, Vosk will **automatically download the language model**
(by default it will download the **small** version). At the same time, it will also print out the list of supported
languages. Then you will see:



This means:


     - The model file ( `vosk-model-small-en-us-0.15` ) has been downloaded.


     - The list of supported languages has been printed.


     - The system is now listening — say something into the PiCar-X microphone, and the recognized text will
appear in the terminal.


**Tips** :


     - Keep the microphone about 15–30 cm away.


**92** **Chapter 3. Think · Talk · Drive — AI-Powered with Multi-LLMs**


**SunFounder PiCar-X Kit**




     - Pick a model that matches your language and accent.


**Streaming Mode (optional)**


You can also stream speech continuously to see partial results as you speak:





**3.4.4 3. Voice Controlled Car**


Now let’s connect speech recognition to the PiCar-X!


We will use a **wake word** (“hey robot”) so the car only listens for commands after being activated. This saves CPU
and prevents unwanted triggers.


**Run the code**





In this program, the car:


  - Waits for the wake word **“hey robot”** .


  - After that, you can speak naturally — as long as your sentence includes one of the keywords ( **forward**, **backward**,
**left**, **right** ), the car will respond.


For example:


**–** “Can you move forward a little?” _→_ the car moves forward.


**–** “Please turn left now.” _→_ the car turns left.


  - The command **“sleep”** stops the control loop and puts the car back into waiting mode.


**Code**







**3.4. 16. Voice Controlled Car with Vosk (Offline)** **93**


**SunFounder PiCar-X Kit**

```
try:
  while True:

```


(continued from previous page)


```
    # --- wait for wake word once --    stt.wait_until_heard(WAKE_WORDS)
    print("Wake word detected. Listening for commands... (say 'sleep' to pause)")

    # --- command loop: multiple commands after one wake --    while True:
      res = stt.listen(stream=False)
      text = res.get("text", "") if isinstance(res, dict) else str(res)
      text = text.lower().strip()
      if not text:
        continue

      print("Heard:", text)

      if "sleep" in text:
        # pause command mode; go back to wait for wake word
        px.stop(); px.set_dir_servo_angle(0)
        print("Sleeping. Say 'hey robot' to wake me again.")
        break

      elif "forward" in text:
        px.set_dir_servo_angle(0)
        px.forward(30); time.sleep(1); px.stop()

      elif "backward" in text:
        px.set_dir_servo_angle(0)
        px.backward(30); time.sleep(1); px.stop()

      elif "left" in text:
        px.set_dir_servo_angle(-25)
        px.forward(30); time.sleep(1)
        px.stop(); px.set_dir_servo_angle(0)

      elif "right" in text:
        px.set_dir_servo_angle(25)
        px.forward(30); time.sleep(1)
        px.stop(); px.set_dir_servo_angle(0)
      # (ignore other words)

except KeyboardInterrupt:
  pass
finally:
  px.stop(); px.set_dir_servo_angle(0)
  print("Stopped and centered. Bye.")

```

**94** **Chapter 3. Think · Talk · Drive — AI-Powered with Multi-LLMs**


**SunFounder PiCar-X Kit**


**3.4.5 Troubleshooting**


   - **No such file or directory (when running `arecord`)**


You may have used the wrong card/device number. Run:

```
   arecord -l

```

and replace `1,0` with the numbers shown for your USB microphone.


   - **Recorded file has no sound**


Open the mixer and check the microphone volume:

```
   alsamixer

```

**–** Press **F6** to select your USB mic.


**–** Make sure **Mic/Capture** is not muted ( **[OO]** instead of **[MM]** ).


**–** Increase the level with ↑.


   - **Vosk does not recognize speech**


**–** Make sure the **language code** matches your model (e.g. `en-us` for English, `zh-cn` for Chinese).


**–** Keep the microphone 15–30 cm away and avoid background noise.


**–** Speak clearly and slowly.


   - **Wake word (“hey robot”) never triggers**


**–** Say it in a natural tone, not too fast.


**–** Check that the program prints recognized text at all. If not, the microphone is not working.


   - **High latency / slow recognition**


**–** The default auto-download is a **small model** (faster, but less accurate).


**–** If it’s still slow, close other programs to free CPU.


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!


**3.4. 16. Voice Controlled Car with Vosk (Offline)** **95**


**SunFounder PiCar-X Kit**

### **3.5 17. Text Vision Talk with Ollama**


In this lesson, you will learn how to use **Ollama**, a tool for running large language and vision models locally. We will
show you how to install Ollama, download a model, and connect PiCar-X to it.


With this setup, PiCar-X can take a camera snapshot and the model will **see and tell** - you can ask any question about
the image, and the model will reply in natural language.


**3.5.1 Before You Start**


Make sure you‘ve completed:


   - _Install All the Modules (Important)_   - Install `robot-hat`, `vilib`, `picar-x` modules, then run the script
`i2samp.sh` .


**3.5.2 1. Install Ollama (LLM) and Download Model**


You can choose where to install **Ollama** :


  - On your Raspberry Pi (local run)


  - Or on another computer (Mac/Windows/Linux) in the **same local network**


**Recommended models vs hardware**


You can choose any model available on . Models come in different sizes (3B, 7B, 13B, 70B...). Smaller models run
faster and require less memory, while larger models provide better quality but need powerful hardware.


Check the table below to decide which model size fits your device.


**Install on Raspberry Pi**


If you want to run Ollama directly on your Raspberry Pi:


  - Use a **64-bit Raspberry Pi OS**


  - Strongly recommended: **Raspberry Pi 5 (16GB RAM)**


Run the following commands:

```
# Install Ollama
curl -fsSL https://ollama.com/install.sh | sh

# Pull a lightweight model (good for testing)
ollama pull llama3.2:3b

```

_`# Quick run test (type`_ _'_ _`hi`_ _'_ _`and press Enter)`_
```
ollama run llama3.2:3b
```

(continues on next page)


**96** **Chapter 3. Think · Talk · Drive — AI-Powered with Multi-LLMs**


**SunFounder PiCar-X Kit**


(continued from previous page)

```
# Serve the API (default port 11434)
# Tip: set OLLAMA_HOST=0.0.0.0 to allow access from LAN
OLLAMA_HOST=0.0.0.0 ollama serve

```

**Install on Mac / Windows / Linux (Desktop App)**


1. Download and install Ollama from


2. Open the Ollama app, go to the **Model Selector**, and use the search bar to find a model. For example, type
`llama3.2:3b` (a small and lightweight model to start with).


**3.5. 17. Text Vision Talk with Ollama** **97**


**SunFounder PiCar-X Kit**


3. After the download is complete, type something simple like “Hi” in the chat window, Ollama will automatically
start downloading it when you first use it.


4. Go to **Settings** _→_ enable **Expose Ollama to the network** . This allows your Raspberry Pi to connect to it over
LAN.


**98** **Chapter 3. Think · Talk · Drive — AI-Powered with Multi-LLMs**


**SunFounder PiCar-X Kit**


**Warning:** If you see an error like:

```
 Error: model requires more system memory ...

```

The model is too large for your machine. Use a **smaller model** or switch to a computer with more RAM.


**3.5.3 2. Test Ollama**


Once Ollama is installed and your model is ready, you can quickly test it with a minimal chat loop.


**Steps**


1. Create a new file:





2. Paste the following code and save ( `Ctrl+X` _→_ `Y` _→_ `Enter` ):

```
   from picarx.llm import Ollama

   INSTRUCTIONS = "You are a helpful assistant."
   WELCOME = "Hello, I am a helpful assistant. How can I help you?"

   # If Ollama runs on the same Raspberry Pi, use "localhost".
```

_`# If it runs on another computer in your LAN, replace with that computer`_ _'_ _`s IP`_ `␣`

(continues on next page)


**3.5. 17. Text Vision Talk with Ollama** **99**


**SunFounder PiCar-X Kit**


_˓→_ _`address.`_
```
   llm = Ollama(
     ip="localhost",
     model="llama3.2:3b" # you can replace with any model
   )

   # Basic configuration
   llm.set_max_messages(20)
   llm.set_instructions(INSTRUCTIONS)
   llm.set_welcome(WELCOME)

   print(WELCOME)

   while True:
     text = input(">>> ")
     if text.strip().lower() in {"exit", "quit"}:
       break

     # Response with streaming output
     response = llm.prompt(text, stream=True)
     for token in response:
       if token:
         print(token, end="", flush=True)
     print("")

```

3. Run the program:

```
   python3 test_llm_ollama.py

```

4. Now you can chat with PiCar-X directly from the terminal.



(continued from previous page)




    - You can choose **any model** available on, but smaller models (e.g. `moondream:1.8b`, `phi3:mini` ) are
recommended if you only have 8–16GB RAM.


     - Make sure the model you specify in the code matches the model you have already pulled in Ollama.


    - Type `exit` or `quit` to stop the program.


     - If you cannot connect, ensure that Ollama is running and that both devices are on the same LAN if you are
using a remote host.


**3.5.4 3. Vision Talk with Ollama**


In this demo, the Pi camera takes a snapshot **each time you type a question** . The program sends **your typed text + the**
**new photo** to a local vision model via Ollama, and then streams the model’s reply in plain English. This is a minimal
“see & tell” baseline you can later extend with color/face/QR checks.


**Before You Start**


1. Open the **Ollama** app (or run the service) and make sure a **vision-capable model** is pulled.


    - If you have enough memory (16GB RAM), you may try `llava:7b` .


    - If you only have **8GB RAM**, prefer a smaller model such as `moondream:1.8b` or `granite3.`
`2-vision:2b` .


**100** **Chapter 3. Think · Talk · Drive — AI-Powered with Multi-LLMs**


**SunFounder PiCar-X Kit**



**Run the Demo**


1. Go to the example folder and run the script:





2. What happens when it runs:


     - The program prints a welcome line and waits for your input ( `>>>` ).


      - **Every time you type anything** (e.g., “hello”, “Is there yellow?”, “Any faces?”, “What is on the desk?”), it:


**– captures a photo** from the Pi camera (saved to `/tmp/llm-img.jpg` ),


**– sends your text + the photo** to the vision model via Ollama,


**– streams back** the model’s answer to the terminal.


    - Type `exit` or `quit` to end the program.


**Code**

```
from picarx.llm import Ollama
from picamera2 import Picamera2
import time

"""
You need to set up Ollama first.
```

(continues on next page)


**3.5. 17. Text Vision Talk with Ollama** **101**


**SunFounder PiCar-X Kit**


(continued from previous page)

```
Note: At least 8GB RAM is recommended for small vision models (e.g., moondream:1.8b).
   For llava:7b, more memory is preferred (16GB).
"""

INSTRUCTIONS = "You are a helpful assistant."
WELCOME = "Hello, I am a helpful assistant. How can I help you?"

# If Ollama runs on the same Pi, use "localhost".
```

_`# If it runs on another computer in your LAN, replace with that computer`_ _'_ _`s IP.`_
```
llm = Ollama(
  ip="localhost", # e.g., "192.168.100.145" if remote
  model="llava:7b" # change to "moondream:1.8b" or "granite3.2-vision:2b" for ␣
```

_˓→_ _`8GB RAM`_
```
)

# Basic configuration
llm.set_max_messages(20)
llm.set_instructions(INSTRUCTIONS)
llm.set_welcome(WELCOME)

# Init camera
camera = Picamera2()
config = camera.create_still_configuration(
  main={"size": (1280, 720)},
)
camera.configure(config)
camera.start()
time.sleep(2)

print(WELCOME)

while True:
  input_text = input(">>> ")
  if input_text.strip().lower() in {"exit", "quit"}:
    break

  # Capture image
  img_path = "/tmp/llm-img.jpg"
  camera.capture_file(img_path)

  # Response with stream (text + image)
  response = llm.prompt(input_text, stream=True, image_path=img_path)
  for next_word in response:
    if next_word:
      print(next_word, end="", flush=True)
  print("")

```

**102** **Chapter 3. Think · Talk · Drive — AI-Powered with Multi-LLMs**


**SunFounder PiCar-X Kit**


**3.5.5 Troubleshooting**


   - **I get an error like: `model requires more system memory ...`.**


**–** This means the model is too large for your device.


**–** Use a smaller model such as `moondream:1.8b` or `granite3.2-vision:2b` .


**–** Or switch to a machine with more RAM and expose Ollama to the network.


   - **The code cannot connect to Ollama (connection refused).**


Check the following:


**–** Make sure Ollama is running ( `ollama serve` or the desktop app is open).


**–** If using a remote computer, enable **Expose to network** in Ollama settings.


**–** Double-check that the `ip="..."` in your code matches the correct LAN IP.


**–** Confirm both devices are on the same local network.


   - **My Pi camera does not capture anything.**


**–** Verify that `Picamera2` is installed and working with a simple test script.


**–** Check that the camera cable is properly connected and enabled in `raspi-config` .


**–** Ensure your script has permission to write to the target path ( `/tmp/llm-img.jpg` ).


   - **The output is too slow.**


**–** Smaller models reply faster, but with simpler answers.


**–** You can lower the camera resolution (e.g., 640×480 instead of 1280×720) to speed up image processing.


**–** Close other programs on your Pi to free up CPU and RAM.


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!


**3.5. 17. Text Vision Talk with Ollama** **103**


**SunFounder PiCar-X Kit**

### **3.6 18. Connecting to Online LLMs**


In this lesson, we’ll learn how to connect your PiCar-X (or Raspberry Pi) to different **online Large Language Models**
**(LLMs)** . Each provider requires an API key and offers different models you can choose from.


We’ll cover how to:


  - Create and save your API keys safely.


  - Pick a model that fits your needs.


  - Run our example code to chat with the models.


Let’s go step by step for each provider.


**3.6.1 Before You Start**


Make sure you‘ve completed:


   - _Install All the Modules (Important)_   - Install `robot-hat`, `vilib`, `picar-x` modules, then run the script
`i2samp.sh` .


**3.6.2 OpenAI**


OpenAI provides powerful models like **GPT-4o** and **GPT-4.1** that can be used for both text and vision tasks.


Here’s how to set it up:


**Get and Save your API Key**


1. Go to and log in. On the **API keys** page, click **Create new secret key** .


**104** **Chapter 3. Think · Talk · Drive — AI-Powered with Multi-LLMs**


**SunFounder PiCar-X Kit**


2. Fill in the details (Owner, Name, Project, and permissions if needed), then click **Create secret key** .


3. Once the key is created, copy it right away — you won’t be able to see it again. If you lose it, you’ll need to
generate a new one.


**3.6. 18. Connecting to Online LLMs** **105**


**SunFounder PiCar-X Kit**


4. In your project folder (for example: `/picar-x/example` ), create a file called `secret.py` :





5. Paste your key into the file like this:





**Enable billing and check models**


1. Before using the key, go to the **Billing** page in your OpenAI account, add your payment details, and top up a
small amount of credits.


**106** **Chapter 3. Think · Talk · Drive — AI-Powered with Multi-LLMs**


**SunFounder PiCar-X Kit**


2. Then go to the **Limits** page to check which models are available for your account and copy the exact model ID
to use in your code.


**Test with example code**


1. Open sample code:


**3.6. 18. Connecting to Online LLMs** **107**


**SunFounder PiCar-X Kit**





2. Replace the content with the code below, and update `model="xxx"` to the model you want (for example, `gpt-4o` ):

```
   from picarx.llm import OpenAI
   from secret import OPENAI_API_KEY

   INSTRUCTIONS = "You are a helpful assistant."
   WELCOME = "Hello, I am a helpful assistant. How can I help you?"

   llm = OpenAI(
     api_key=OPENAI_API_KEY,
     model="gpt-4o",
   )

```

Save and exit ( `Ctrl+X`, then `Y`, then `Enter` ).


3. Finally, run the test:

```
   sudo python3 18.online_llm_test.py

```

**3.6.3 Gemini**


Gemini is Google’s family of AI models. It’s fast and great for general-purpose tasks.


**Get and Save your API Key**


1. Log in to, then go to the API Keys page.


**108** **Chapter 3. Think · Talk · Drive — AI-Powered with Multi-LLMs**


**SunFounder PiCar-X Kit**


2. Click the **Create API key** button in the top-right corner.


3. You can create a key for an existing project or a new one.


**3.6. 18. Connecting to Online LLMs** **109**


**SunFounder PiCar-X Kit**


4. Copy the generated API key.


5. In your project folder:





6. Paste the key:





**Check available models**


Go to the official page, here you’ll see the list of models, their exact API IDs, and which use case each one is optimized
for.


**110** **Chapter 3. Think · Talk · Drive — AI-Powered with Multi-LLMs**


**SunFounder PiCar-X Kit**



**Test with example code**


1. Open the test file:





2. Replace the content with the code below, and update `model="xxx"` to the model you want (for example,
`gemini-2.5-flash` ):

```
   from picarx.llm import Gemini
   from secret import GEMINI_API_KEY

   INSTRUCTIONS = "You are a helpful assistant."
   WELCOME = "Hello, I am a helpful assistant. How can I help you?"

   llm = Gemini(
     api_key=GEMINI_API_KEY,
     model="gemini-2.5-flash",
   )

```

3. Save and run:

```
   sudo python3 18.online_llm_test.py

```

**3.6. 18. Connecting to Online LLMs** **111**


**SunFounder PiCar-X Kit**


**3.6.4 Qwen**


Qwen is a family of large language and multimodal models provided by Alibaba Cloud. These models support text
generation, reasoning, and multimodal understanding (such as image analysis).


**Get an API Key**


To call Qwen models, you need an **API Key** . Most international users should use the **DashScope International (Model**
**Studio)** console. Mainland China users can instead use the **Bailian ()** console.


   - **For International Users**


1. Go to the official page on **Alibaba Cloud** .


2. Sign in or create an **Alibaba Cloud** account.


3. Navigate to **Model Studio** (choose Singapore or Beijing region).


**–** If an “Activate Now” prompt appears at the top of the page, click it to activate Model Studio and receive
the free quota (Singapore only).


**–** Activation is free — you will only be charged after your free quota is used.


**–** If no activation prompt appears, the service is already active.


4. Go to the **Key Management** page. On the **API Key** tab, click **Create API Key** .


5. After creation, copy your API Key and keep it safe.


**Note:** Users in Hong Kong, Macau, and Taiwan should also choose the **International (Model Studio)** option.


   - **For Mainland China Users**


If you are in Mainland China, you can use the **Alibaba Cloud Bailian ()** console instead:


1. Log in to (Bailian console) and complete account verification.


2. Select **Create API Key** . If prompted that model services are not activated, click **Activate**, agree to the
terms, and claim your free quota. After activation, the **Create API Key** button will be enabled.


**112** **Chapter 3. Think · Talk · Drive — AI-Powered with Multi-LLMs**


**SunFounder PiCar-X Kit**


3. Click **Create API Key** again, check your account, and then click **Confirm** .


**3.6. 18. Connecting to Online LLMs** **113**


**SunFounder PiCar-X Kit**


4. Once created, copy your API Key.


**Save your API Key**


1. In your project folder:





2. Paste your key like this:


**114** **Chapter 3. Think · Talk · Drive — AI-Powered with Multi-LLMs**


**SunFounder PiCar-X Kit**



**Test with example code**


1. Open the test file:





2. Replace the content with the code below, and update `model="xxx"` to the model you want (for example,
`qwen-plus` ):

```
   from picarx.llm import Qwen
   from secret import QWEN_API_KEY

   INSTRUCTIONS = "You are a helpful assistant."
   WELCOME = "Hello, I am a helpful assistant. How can I help you?"

   llm = Qwen(
     api_key=QWEN_API_KEY,
     model="qwen-plus",
   )

```

3. Run with:

```
   sudo python3 18.online_llm_test.py

```

**3.6.5 Grok (xAI)**


Grok is xAI’s conversational AI, created by Elon Musk’s team. You can connect to it through the xAI API.


**Get and Save your API Key**


1. Sign up for an account here: . Add some credits to your account first — otherwise the API won’t work.


2. Go to the API Keys page, click **Create API key** .


3. Enter a name for the key, then click **Create API key** .


**3.6. 18. Connecting to Online LLMs** **115**


**SunFounder PiCar-X Kit**


4. Copy the generated key and keep it safe.


5. In your project folder:


**116** **Chapter 3. Think · Talk · Drive — AI-Powered with Multi-LLMs**


**SunFounder PiCar-X Kit**





6. Paste your key like this:



**Check available models**


Go to the Models page in the xAI console. Here you can see all the models available to your team, along with their
exact API IDs — use these IDs in your code.


**Test with example code**


1. Open the test file:





2. Replace the content with the code below, and update `model="xxx"` to the model you want (for example,
`grok-4-latest` ):

```
   from picarx.llm import Grok
   from secret import GROK_API_KEY

   INSTRUCTIONS = "You are a helpful assistant."
```

(continues on next page)


**3.6. 18. Connecting to Online LLMs** **117**


**SunFounder PiCar-X Kit**


(continued from previous page)

```
   WELCOME = "Hello, I am a helpful assistant. How can I help you?"

   llm = Grok(
     api_key=GROK_API_KEY,
     model="grok-4-latest",
   )

```

3. Run with:

```
   sudo python3 18.online_llm_test.py

```

**3.6.6 DeepSeek**


DeepSeek is a Chinese LLM provider that offers affordable and capable models.


**Get and Save your API Key**


1. Log in to .


2. In the top-right menu, select **API Keys** _→_ **Create API Key** .


3. Enter a name, click **Create**, then copy the key.


**118** **Chapter 3. Think · Talk · Drive — AI-Powered with Multi-LLMs**


**SunFounder PiCar-X Kit**



4. In your project folder:





5. Add your key:





**Enable billing**


You’ll need to recharge your account first. Start with a small amount (like ¥10 RMB).


**Available models**


At the time of writing (2025-09-12), DeepSeek offers:


**3.6. 18. Connecting to Online LLMs** **119**


**SunFounder PiCar-X Kit**


   - `deepseek-chat`


   - `deepseek-reasoner`


**Test with example code**


1. Open the test file:





2. Replace the content with the code below, and update `model="xxx"` to the model you want (for example,
`deepseek-chat` ):



3. Run:

```
   sudo python3 18.online_llm_test.py

```

**3.6.7 Doubao**


Doubao is ByteDance’s AI model platform (Volcengine Ark).


**Get and Save your API Key**


1. Log in to .


2. In the left menu, scroll down to **API Key Management** _→_ **Create API Key** .


**120** **Chapter 3. Think · Talk · Drive — AI-Powered with Multi-LLMs**


**SunFounder PiCar-X Kit**


3. Choose a name and click **Create** .


**3.6. 18. Connecting to Online LLMs** **121**


**SunFounder PiCar-X Kit**


4. Click the **Show API Key** icon and copy it.


5. In your project folder:





6. Add your key:





**Choose a model**


1. Go to the model marketplace and pick a model.


**122** **Chapter 3. Think · Talk · Drive — AI-Powered with Multi-LLMs**


**SunFounder PiCar-X Kit**


2. For example, choose **Doubao-seed-1.6**, then click **API** .


**3.6. 18. Connecting to Online LLMs** **123**


**SunFounder PiCar-X Kit**


3. Select your API Key and click **Use API** .


**124** **Chapter 3. Think · Talk · Drive — AI-Powered with Multi-LLMs**


**SunFounder PiCar-X Kit**


4. Click **Enable Model** .


5. Hover over the model ID to copy it.


**3.6. 18. Connecting to Online LLMs** **125**


**SunFounder PiCar-X Kit**


**Test with example code**


1. Open the test file:





2. Replace the content with the code below, and update `model="xxx"` to the model you want (for example,
`doubao-seed-1-6-250615` ):

```
   from picarx.llm import Doubao
   from secret import DOUBAO_API_KEY

   INSTRUCTIONS = "You are a helpful assistant."
   WELCOME = "Hello, I am a helpful assistant. How can I help you?"

   llm = Doubao(
     api_key=DOUBAO_API_KEY,
     model="doubao-seed-1-6-250615",
   )

```

3. Run with:

```
   sudo python3 18.online_llm_test.py

```

**126** **Chapter 3. Think · Talk · Drive — AI-Powered with Multi-LLMs**


**SunFounder PiCar-X Kit**


**3.6.8 General**


This project supports connecting to multiple LLM platforms through a unified interface. We have built-in compatibility
with:


   - **OpenAI** (ChatGPT / GPT-4o, GPT-4, GPT-3.5)


   - **Gemini** (Google AI Studio / Vertex AI)


   - **Grok** (xAI)


   - **DeepSeek**


   - **Qwen ()**


   - **Doubao ()**


In addition, you can connect to **any other LLM service that is compatible with the OpenAI API format** . For those
platforms, you will need to manually obtain your **API Key** and the correct **base_url** .


**Get and Save Your API Key**


1. Obtain an **API Key** from the platform you want to use. (See each platform’s official console for details.)


2. In your project folder, create a new file:





3. Add your key into `secret.py` :





**Warning:** Keep your API Key private. Do not upload `secret.py` to public repositories.


**Test With Example Code**


1. Open the test file:





2. Replace the content of a Python file with the following example, and fill in the correct `base_url` and `model` for
your platform:


**Note:** About `base_url` : We support the **OpenAI API format**, as well as any API that is **compatible** with it.
Each provider has its own `base_url` . Please check their documentation.

```
   from picarx.llm import LLM
   from secret import API_KEY

   INSTRUCTIONS = "You are a helpful assistant."
   WELCOME = "Hello, I am a helpful assistant. How can I help you?"

   llm = LLM(
```

(continues on next page)


**3.6. 18. Connecting to Online LLMs** **127**


**SunFounder PiCar-X Kit**


(continued from previous page)

```
     base_url="https://api.example.com/v1", # fill in your provider’s base_url
     api_key=API_KEY,
     model="your-model-name-here", # choose a model from your provider
   )

```

3. Run the program:

```
   python3 18.online_llm_test.py

```

**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!

### **3.7 19. Local Voice Chatbot**


In this lesson, you will combine everything you’ve learned — **speech recognition (STT)**, **text-to-speech (TTS)**, and
a **local LLM (Ollama)** - to build a fully offline **voice chatbot** that runs on your PiCar-X system.


The workflow is simple:


1. **Listen**  - The microphone captures your speech and transcribes it with **Vosk** .


2. **Think**  - The text is sent to a local **LLM** running on Ollama (e.g., `llama3.2:3b` ).


3. **Speak**  - The chatbot answers aloud using **Piper TTS** .


This creates a **hands-free conversational robot** that can understand and respond in real time.


**3.7.1 Before You Start**


Make sure you have prepared the following:


   - _Install All the Modules (Important)_   - Install `robot-hat`, `vilib`, `picar-x` modules, then run the script
`i2samp.sh` .


  - Tested **Piper TTS** ( _1. Testing Piper_ ) and chosen a working voice model.


  - Tested **Vosk STT** ( _2. Test Vosk_ ) and chosen the right language pack (e.g., `en-us` ).


  - Installed **Ollama** ( _1. Install Ollama (LLM) and Download Model_ ) on your Pi or another computer, and downloaded a model such as `llama3.2:3b` (or a smaller one like `moondream:1.8b` if memory is limited).


**128** **Chapter 3. Think · Talk · Drive — AI-Powered with Multi-LLMs**


**SunFounder PiCar-X Kit**



**3.7.2 Run the Code**


1. Open the example script:





2. Update the parameters as needed:


    - `stt = Vosk(language="en-us")` : Change this to match your accent/language package (e.g., `en-us`,
`zh-cn`, `es` ).


    - `tts.set_model("en_US-amy-low")` : Replace with the Piper voice model you verified in _1. Testing_
_Piper_ .


    - `llm = Ollama(ip="localhost", model="llama3.2:3b")` : Update both `ip` and `model` to your own
setup.


**–** `ip` : If Ollama runs on the **same Pi**, use `localhost` . If Ollama runs on another computer in your LAN,
enable **Expose to network** in Ollama and set `ip` to that computer’s LAN IP.


**–** `model` : Must exactly match the model name you downloaded/activated in Ollama.


3. Run the script:





4. After running, you should see:


     - The bot greets you with a spoken welcome message.


     - It waits for speech input.


     - Vosk transcribes your speech into text.


     - The text is sent to Ollama, which streams back a reply.


     - The reply is cleaned (removing hidden reasoning) and spoken aloud by Piper.


     - Stop the program anytime with `Ctrl+C` .


**3.7.3 Code**



**3.7. 19. Local Voice Chatbot** **129**


**SunFounder PiCar-X Kit**


(continued from previous page)

```
# Instructions for the LLM
INSTRUCTIONS = (
  "You are a helpful assistant. Answer directly in plain English. "
  "Do NOT include any hidden thinking, analysis, or tags like <think>."
)
WELCOME = "Hello! I'm your voice chatbot. Speak when you're ready."

# Initialize Ollama connection
llm = Ollama(ip="localhost", model="llama3.2:3b")
llm.set_max_messages(20)
llm.set_instructions(INSTRUCTIONS)

# Utility: clean hidden reasoning
def strip_thinking(text: str) -> str:
  if not text:
    return ""
  text = re.sub(r"<\s*think[^>]*>.*?<\s*/\s*think\s*>", "", text, flags=re.DOTALL|re.
```

_˓→_ `IGNORECASE)`
```
  text = re.sub(r"<\s*thinking[^>]*>.*?<\s*/\s*thinking\s*>", "", text, flags=re.
```

_˓→_ `DOTALL|re.IGNORECASE)`
```
  text = re.sub(r"���(?:\s*thinking)?\s*.*?���", "", text, flags=re.DOTALL|re.
```

_˓→_ `IGNORECASE)`
```
  text = re.sub(r"\[/?thinking\]", "", text, flags=re.IGNORECASE)
  return re.sub(r"\s+\n", "\n", text).strip()

def main():
  print(WELCOME)
  tts.say(WELCOME)

  try:
    while True:
      print("\n Listening... (Press Ctrl+C to stop)")

      # Collect final transcript from Vosk
      text = ""
      for result in stt.listen(stream=True):
        if result["done"]:
          text = result["final"].strip()
          print(f"[YOU] { text } ")
        else:
          print(f"[YOU] { result['partial'] } ", end="\r", flush=True)

      if not text:
        print("[INFO] Nothing recognized. Try again.")
        time.sleep(0.1)
        continue

      # Query Ollama with streaming
      reply_accum = ""
      response = llm.prompt(text, stream=True)
      for next_word in response:
        if next_word:

```

(continues on next page)


**130** **Chapter 3. Think · Talk · Drive — AI-Powered with Multi-LLMs**


**SunFounder PiCar-X Kit**


(continued from previous page)

```
          print(next_word, end="", flush=True)
          reply_accum += next_word
      print("")

      # Clean and speak
      clean = strip_thinking(reply_accum)
      if clean:
        tts.say(clean)
      else:
        tts.say("Sorry, I didn't catch that.")

      time.sleep(0.05)

  except KeyboardInterrupt:
    print("\n[INFO] Stopping...")
  finally:
    tts.say("Goodbye!")
    print("Bye.")

if __name__ == "__main__":
  main()

```

**3.7.4 Code Analysis**


**Imports and global setup**





Brings in the three subsystems you built earlier: **Vosk** for speech-to-text (STT), **Ollama** for the LLM, and **Piper** for
text-to-speech (TTS).


**Initialize STT (Vosk)**

```
stt = Vosk(language="en-us")

```

Loads the Vosk model for US English. Change the language code (e.g., `zh-cn`, `es` ) to match your voice pack for better
accuracy.


**Initialize TTS (Piper)**





Creates a Piper engine and selects a specific voice. Pick a model you’ve tested in _1. Testing Piper_ . Lower-quality
voices are faster and use less CPU.


**LLM instructions and welcome line**


**3.7. 19. Local Voice Chatbot** **131**


**SunFounder PiCar-X Kit**



Two key UX choices:


  - Keep **answers short and direct** (helps with TTS clarity).


  - Explicitly forbid hidden “chain-of-thought” tags to reduce noisy outputs.


**Connect to Ollama and set conversation scope**






   - `ip="localhost"` assumes the Ollama server runs on the same Pi. If it runs on another LAN machine, put that
computer’s **LAN IP** and enable _Expose to network_ in Ollama.


   - `set_max_messages(20)` keeps a short conversational history. Lower this if memory/latency is tight.


**Strip hidden reasoning / tags before speaking**







Some models may emit internal-style tags (e.g., `<think>...` ). This function removes those so your TTS **only** speaks
the final answer.


**Tip:** If you see other artifacts on screen (because you stream raw tokens), this function already ensures **spoken** output
stays clean.


**Main loop: greet once, then listen** _→_ **think** _→_ **speak**





Greets the user via terminal and speaker. Happens once at startup.


**Listen (streaming STT with live partials)**

```
print("\n Listening... (Press Ctrl+C to stop)")

text = ""
for result in stt.listen(stream=True):
  if result["done"]:
```

(continues on next page)


**132** **Chapter 3. Think · Talk · Drive — AI-Powered with Multi-LLMs**


**SunFounder PiCar-X Kit**


(continued from previous page)

```
    text = result["final"].strip()
    print(f"[YOU] { text } ")
  else:
    print(f"[YOU] { result['partial'] } ", end="\r", flush=True)

```

   - `stream=True` yields **partial** transcripts for immediate feedback and a **final** transcript when the utterance ends.


  - The final recognized text is stored in `text` and printed once.


**Guard:** If nothing was recognized, you skip the LLM call:



This avoids sending empty prompts to the model (saves time and tokens).


**Think (LLM) with streamed printing**

```
reply_accum = ""
response = llm.prompt(text, stream=True)
for next_word in response:
  if next_word:
    print(next_word, end="", flush=True)
    reply_accum += next_word
print("")

```

  - Sends the final transcript to the local LLM and **prints tokens as they arrive** for low latency.


  - Meanwhile, you accumulate the full reply in `reply_accum` for post-processing.


**Note:** If you’d rather **not** show raw tokens, set `stream=False` and just print the final string.


**Speak (clean first, then TTS once)**






  - Cleans the final text to remove hidden tags, then **speaks exactly once** .


  - Keeping TTS to a single pass avoids repeated prompts like “[LLM] / [SAY]”.


**Exit and teardown**





Use **Ctrl+C** to stop. The bot says a short goodbye to signal a clean exit.


**3.7. 19. Local Voice Chatbot** **133**


**SunFounder PiCar-X Kit**


**3.7.5 Troubleshooting & FAQ**


   - **Model is too large (memory error)**


Use a smaller model like `moondream:1.8b` or run Ollama on a more powerful computer.


   - **No response from Ollama**


Make sure Ollama is running ( `ollama serve` or desktop app open). If remote, enable **Expose to network** and
check IP address.


   - **Vosk not recognizing speech**


Verify your microphone works. Try another language pack ( `zh-cn`, `es` etc.) if needed.


   - **Piper silent or errors**


Confirm the chosen voice model is downloaded and tested in _1. Testing Piper_ .


   - **Answers too long or off-topic**


Edit `INSTRUCTIONS` to add: **“Keep answers short and to the point.”**


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!

### **3.8 20. Treasure Hunt**


In this lesson, you will turn your PiCar-X into a **treasure hunter robot** . Arrange a maze in your room and place six
different color cards in different corners. Your PiCar-X will **search, recognize, and celebrate** when it finds the target
color.


This project combines three skills you’ve learned so far:


   - **Computer Vision**   - detecting colored cards with the Pi camera.


   - **Keyboard Control**   - driving the robot manually through the maze.


   - **Speech Feedback**   - Pico2Wave announces the target color and success.


It’s a fun game that shows how robots can **see, think, and act** just like treasure hunters!


**Note:** You can download and print the `PDF Color Cards` for reliable color detection.


**134** **Chapter 3. Think · Talk · Drive — AI-Powered with Multi-LLMs**


**SunFounder PiCar-X Kit**


**3.8.1 Before You Start**


Make sure you‘ve completed:


   - _Install All the Modules (Important)_   - Install `robot-hat`, `vilib`, `picar-x` modules, then run the script
`i2samp.sh` .


**3.8.2 Run the Code**





After running, you’ll see a message like this:

```
* Running on http://0.0.0.0:9000/ (Press CTRL+C to quit)

```

Then, open `http://<your IP>:9000/mjpg` in your browser to view the live video feed. Example: `http://192.`
```
168.18.113:9000/mjpg

```

**3.8.3 Game Rules**


1. The robot randomly selects a **target color** and says: **“Look for red!”**


2. You drive PiCar-X with the keyboard:


      - `w` = forward


      - `a` = turn left


      - `s` = backward


      - `d` = turn right


      - `space` = repeat target


      - `Ctrl+C` = quit


3. When the camera sees the target color card, PiCar-X says **“Well done!”**


4. A new target color is chosen, and the hunt continues!


**3.8.4 Code**

```
#!/usr/bin/env python3

from picarx import Picarx
from vilib import Vilib
from picarx.tts import Pico2Wave

from time import sleep
```

(continues on next page)


**3.8. 20. Treasure Hunt** **135**


**SunFounder PiCar-X Kit**


(continued from previous page)

```
import threading
import readchar
import random

# ----------------------# Settings
# ----------------------COLORS = ["red", "orange", "yellow", "green", "blue", "purple"]
DETECTION_WIDTH_THRESHOLD = 100 # how wide the color blob must be
DRIVE_SPEED = 80
TURN_ANGLE = 30

MANUAL = """
Press keys to control PiCar-X:
 w: forward a: turn left s: backward d: turn right
 space: repeat target Ctrl+C: quit
"""

# ----------------------# Init
# ----------------------px = Picarx()

tts = Pico2Wave()
tts.set_lang("en-US")

current_color = "red"
key = None
lock = threading.Lock()

def say(line: str):
  print(f"[SAY] { line } ")
  tts.say(line)

def renew_color_detect():
  """Choose a new target color and start detection."""
  global current_color
  current_color = random.choice(COLORS)
  Vilib.color_detect(current_color)
  say(f"Look for { current_color } !")

def key_scan_thread():
  """Background thread reading keys."""
  global key
  while True:
    k = readchar.readkey()
    # Map special keys before lowercasing
    if k == readchar.key.SPACE:
      mapped = "space"
    elif k == readchar.key.CTRL_C:
      mapped = "quit"
    else:

```

(continues on next page)


**136** **Chapter 3. Think · Talk · Drive — AI-Powered with Multi-LLMs**


**SunFounder PiCar-X Kit**


(continued from previous page)

```
      mapped = k.lower()

    with lock:
      key = mapped

    if mapped == "quit":
      return
    sleep(0.01)

def car_move(k: str):
  if k == "w":
    px.set_dir_servo_angle(0)
    px.forward(DRIVE_SPEED)
  elif k == "s":
    px.set_dir_servo_angle(0)
    px.backward(DRIVE_SPEED)
  elif k == "a":
    px.set_dir_servo_angle(-TURN_ANGLE)
    px.forward(DRIVE_SPEED)
  elif k == "d":
    px.set_dir_servo_angle(TURN_ANGLE)
    px.forward(DRIVE_SPEED)

def main():
  global key

  # Start camera and web preview
  Vilib.camera_start(vflip=False, hflip=False)
  Vilib.display(local=False, web=True)
  sleep(0.8)

  print(MANUAL.strip())
  say("Game start!")
  sleep(0.1)
  renew_color_detect()

  # Start keyboard thread (modern style)
  key_thread = threading.Thread(target=key_scan_thread, daemon=True)
  key_thread.start()

  try:
    while True:
      # Check detection: if target color present and wide enough
      if (Vilib.detect_obj_parameter.get("color_n", 0) != 0 and
        Vilib.detect_obj_parameter.get("color_w", 0) > DETECTION_WIDTH_
```

_˓→_ `THRESHOLD):`
```
        say("Well done!")
        sleep(0.1)
        renew_color_detect()

      # Take a snapshot of the last key (and clear it)
      with lock:

```

(continues on next page)


**3.8. 20. Treasure Hunt** **137**


**SunFounder PiCar-X Kit**


(continued from previous page)

```
        k = key
        key = None

      # Handle movement / actions
      if k in ("w", "a", "s", "d"):
        car_move(k)
        sleep(0.5)
        px.stop()
      elif k == "space":
        say(f"Look for { current_color } !")
      elif k == "quit":
        print("\n[INFO] Quit requested.")
        break

      sleep(0.05)

  except KeyboardInterrupt:
    print("\n[INFO] Stopped by user.")
  finally:
    try:
      Vilib.camera_close()
    except Exception:
      pass
    px.stop()
    say("Goodbye!")
    sleep(0.2)

if __name__ == "__main__":
  main()

```

**3.8.5 How It Works**


1. **Initialization**


     - Import modules and configure PiCar-X, camera, and TTS.


     - Set color list, speed, and steering angle.


2. **Target Selection**


      - `renew_color_detect()` randomly picks a target color.


     - The robot announces the target with Pico2Wave.


3. **Keyboard Control**


      - `key_scan_thread()` runs in the background to capture keys.


    - Keys `w, a, s, d` control motion; `space` repeats target.


4. **Color Detection**


     - Camera constantly checks if the target color is visible.


     - If the detected blob is large enough, PiCar-X celebrates.


5. **Main Loop**


**138** **Chapter 3. Think · Talk · Drive — AI-Powered with Multi-LLMs**


**SunFounder PiCar-X Kit**


     - Continuously handles movement, detection, and feedback.


     - Cleanly stops the robot and camera when quitting.


**3.8.6 Troubleshooting**


   - **Camera feed not working?**


Run `libcamera-hello` to check if the Pi camera is connected properly.


   - **Robot doesn’t detect colors?**


Ensure the cards are printed clearly and placed in good lighting. Try adjusting `DETECTION_WIDTH_THRESHOLD` .


   - **No voice feedback?**


Check that `pico2wave` is installed and your audio output is configured.


   - **Car doesn’t move?**


Verify PiCar-X power is on and the motor calibration is correct.


By completing this lesson, you’ve built a **mini treasure hunt game** with PiCar-X, combining **vision, control, and**
**interaction** into one project!


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!

### **3.9 21. AI Voice Assistant Car**


This lesson turns your PiCar-X into an **AI-powered voice assistant on wheels** . The robot can wake up to your voice,
recognize what you say, talk back with emotion, and act out its “feelings” through movements, gestures, and lights.


You’ll build a **fully interactive voice assistant car** using:


   - **LLM**   - Large Language Model (OpenAI GPT or Doubao).


   - **STT**   - Speech-to-Text (voice to text).


   - **TTS**   - Text-to-Speech (text to voice).


   - **Sensors + Actions**   - Ultrasonic, camera, and built-in expressive actions.


**3.9. 21. AI Voice Assistant Car** **139**


**SunFounder PiCar-X Kit**


**3.9.1 Before You Start**


Make sure you‘ve completed:


   - _Install All the Modules (Important)_   - Install `robot-hat`, `vilib`, `picar-x` modules, then run the script
`i2samp.sh` .


   - _1. Testing Piper_   - Check the supported languages of **Piper TTS** .


   - _2. Test Vosk_   - Check the supported languages of **Vosk STT** .


   - _18. Connecting to Online LLMs_   - This step is **very important** : obtain your **OpenAI** or **Doubao** API key, or
the API key for any other supported LLM.


You should already have:


  - A working **microphone** and **speaker** on your PiCar-X.


  - A **valid API key** stored in `secret.py` .


  - A stable network connection (a **wired connection** is recommended for better stability).


**3.9.2 Run the Example**


Both language versions are placed in the same directory:

```
cd ~/picar-x/example

```

**English version** (OpenAI GPT, instructions in English):

```
sudo python3 21.voice_active_car_gpt.py

```

  - LLM: `OpenAI GPT-4o-mini`


  - TTS: `en_US-ryan-low` (Piper)


  - STT: Vosk ( `en-us` )


Wake word:

```
"Hey buddy"

```



**Chinese version** (Doubao, instructions in Chinese):

```
sudo python3 21.voice_active_car_doubao_cn.py

```

  - LLM: `Doubao-seed-1-6-250615`


  - TTS: `zh_CN-huayan-x_low` (Piper)


  - STT: Vosk ( `cn` )


Wake word:

```
" "

```

**140** **Chapter 3. Think · Talk · Drive — AI-Powered with Multi-LLMs**


**SunFounder PiCar-X Kit**


**Note:** You can modify the **wake word** and **robot name** in the code: `NAME = "Buddy"` or `NAME = "" WAKE_WORD =`

`["hey buddy"]` or `WAKE_WORD = [" "]`


**3.9.3 What Will Happen**


When you run this example successfully:


  - The robot **waits for the wake word** (e.g., “Hey Buddy” / “ ”).


  - When it hears the wake word:


**–** LEDs will **blink** and stay on.


**–** The robot **greets you** with a cheerful voice.


   - It then starts **listening to your voice** in real time.


  - After recognizing what you said, it:


**–** Sends your speech to the **LLM** (OpenAI or Doubao).


**– Thinks** and blinks LED while processing.


**–** Replies with **TTS voice** .


**–** Executes **corresponding actions** (e.g., nodding, turning, celebrating).


  - If you approach it too closely, the ultrasonic sensor:


**–** Triggers an auto **backward** move for safety.


**–** Interrupts the current round with a warning response.


**Example interaction**


**3.9.4 Switching to Other LLMs or TTS**


You can easily switch to other LLMs, TTS, or STT languages with just a few edits:


  - Supported LLMs:


**–** OpenAI


**–** Doubao


**–** Deepseek


**–** Gemini


**–** Qwen


**3.9. 21. AI Voice Assistant Car** **141**


**SunFounder PiCar-X Kit**


**–** Grok


   - _1. Testing Piper_   - Check the supported languages of **Piper TTS** .


   - _2. Test Vosk_   - Check the supported languages of **Vosk STT** .


To switch, simply modify the initialization part in the code:



**3.9.5 Action & Sound Reference**


Below are the **action keywords** the LLM can return (after the `ACTIONS:` line) and what they do on the robot.





















**Movement & Utility**


**142** **Chapter 3. Think · Talk · Drive — AI-Powered with Multi-LLMs**


**SunFounder PiCar-X Kit**


**Sound Effects**


**Sensor Triggers (Automatic)**


   - **Ultrasonic proximity**


**–** Trigger: distance < 10 cm


**–** Side effect: auto `backward` + disable image for this round


**–** Injected message: `<<<Ultrasonic sense too close:` `{distance}cm>>>`


**Lifecycle Hooks (LED Indicators)**


   - `before_listen` _→_ blink twice (ready to listen)


   - `before_think` _→_ blinking (thinking)


   - `before_say` _→_ LED on (speaking)


   - `after_say` _→_ wait for actions _→_ LED off


   - `on_stop` _→_ stop actions, close devices


**3.9.6 Troubleshooting**


   - **The robot doesn’t respond to wake word**


**–** Check if the microphone works.


**–** Ensure `WAKE_ENABLE = True` .


**–** Adjust wake word to match your pronunciation.


   - **No sound from the speaker**


**–** Verify TTS model setup.


**–** Test Piper or Espeak manually.


**–** Check speaker connection and volume.


   - **API Key error or timeout**


**–** Check your key in `secret.py` .


**–** Ensure network connection.


**–** Confirm the LLM is supported.


   - **Picar-X doesn’t move or act**


**3.9. 21. AI Voice Assistant Car** **143**


**SunFounder PiCar-X Kit**


**–** Check that the action name matches `actions_dict` .


**–** Verify motor and servo connections.


   - **Ultrasonic sensor keeps triggering unexpectedly.**


**–** Check sensor installation height and angle.


**–** Adjust the `TOO_CLOSE` distance threshold in code.


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!


**144** **Chapter 3. Think · Talk · Drive — AI-Powered with Multi-LLMs**


**CHAPTER**

### **FOUR** **PYTHON VIDEO COURSE**


This video course is an online Python tutorial specifically designed for interactive learning. It includes three introductory videos that cover the essential foundations: starting with setting up the Raspberry Pi, assembling the PiCar-X, and
then installing the necessary robot modules. This initial phase ensures that everything is prepared before beginning the
various projects with the PiCar-X.


Following the introductory section, the course features 12 project videos. These projects progressively develop skills
starting from basic movement of the PiCar-X, keyboard control, Text-to-Speech (TTS), obstacle avoidance, line tracking, to applications in computer vision. The course then advances to more complex projects that combine multiple
functionalities. Besides teaching you to run examples from the online tutorial, the videos also provide additional extensions to each topic, allowing for a deeper understanding of each feature.


**Get Started**


The course begins with three introductory videos that lay the foundation for working with the PiCar-X. These videos
cover:


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!

### **4.1 Video A1: Starting with Raspbrry Pi**


This is the first video for the PiCar-X.


This video provides a comprehensive tutorial on setting up a Raspberry Pi for use with the PiCar-X robot car. It covers:


  - The features of the PiCar-X.


  - How to image the Raspberry Pi OS.


  - Various programming methods including using HDMI, PowerShell, Remote Desktop, and SunFounder Create
Agent.


**145**


**SunFounder PiCar-X Kit**


  - Installing necessary robot modules.


If you are a beginner, it is suggested to follow the steps one by one. If you are more familiar with Raspberry Pi, then
you can directly follow the latter part of the video to install the necessary modules.


**Video**


**Related On-line Tutorials**


   - _1. Quick Guide on Python_


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!

### **4.2 Video A2: Assembly of the PICAR-X**


In this video, the focus is on assembling the PICAR-X.


Key aspects of the tutorial include:


   - **Unboxing** : Introduction of the kit components, including the assembly instruction sheet, tools, modules, and
motors.


   - **Assembly Guide** : Detailed steps for assembling the PICAR-X, starting from attaching screws to the Raspberry
Pi, connecting cables, and setting up the robot hat.


   - **Servo Calibration** : Using SunFounder’s Create Agent for zeroing the servos.


   - **Motor and Battery Installation** : Attaching motors to the frame and securing the battery.


   - **Sensor and Camera Installation** : Installing and connecting the grayscale sensor, ultrasonic sensor, and camera.


   - **Wiring and Final Setup** : Organizing and connecting wires for various components, followed by final checks
and tidy wire management.


The video is designed to guide you through each step of the assembly process, ensuring a thorough understanding of
how each component fits together.


**Video**


**Related On-line Tutorials**


   - _Assemble the PiCar-X_


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


**146** **Chapter 4. Python Video Course**


**SunFounder PiCar-X Kit**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!

### **4.3 Video A3: Calibrate the PiCar-X**


This third video in the series focuses on calibrating the PiCar-X and introducing the Robot HAT. The tutorial is divided
into several key sections:


   - **Greyscale Sensor Calibration** : Instructions on accessing and calibrating the greyscale sensor.


   - **DC Motors and Servo Calibration** : Steps for calibrating the DC motors for direction and speed, as well as the
steering and camera pan/tilt servos.


   - **Script Automation at Startup** : How to set scripts to run automatically at the Raspberry Pi’s startup.


   - **Robot HAT Overview** : Detailed overview of the Robot HAT, including its features and functionalities.


This tutorial is crucial for those looking to fine-tune their PiCar-X and understand the technical aspects of the Robot
HAT.


**Video**


**Related On-line Tutorials**


   - _1. Calibrating the PiCar-X_


**Projects**


Following the setup, the course dives into twelve project-based videos. These videos progressively enhance the capabilities of the PiCar-X, starting from basic movements to more complex tasks, including:


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!


**4.3. Video A3: Calibrate the PiCar-X** **147**


**SunFounder PiCar-X Kit**

### **4.4 Video 1: Motor Move and Steering Control**


This video serves as the first project tutorial in the PiCar-X series, focusing on how to control the motors and steering
servo of the PiCar-X. The key contents include:


   - **Starting and Stopping Motors** : Demonstrates how to control the movement of the PiCar-X, including moving
forward and backward.


   - **Motor Speed Control** : Shows how to increase and decrease the speed of the motors.


   - **Steering Control** : Teaches how to turn left and right by controlling the front steering servo.


   - **Script Execution** : Illustrates how to run a program automatically when the Raspberry Pi starts.


   - **Move.py Code Analysis** : Offers an in-depth explanation of the Move.py script, detailing the logic behind controlling motors and steering.


   - **Testing and Debugging** : Practical testing to ensure both the code and hardware function correctly.


This video is an excellent practical guide for beginners to PiCar-X, providing detailed instructions on controlling motors
and steering, laying a solid foundation for further project development.


**Video**


**Related On-line Tutorials**


   - _2. Let PiCar-X Move_


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!

### **4.5 Video 2: Controlling the PiCar-X using keyboard**


In this video tutorial, you’ll learn how to control the PiCar-X robot using a keyboard. It covers:


   - **Basic Control** : Demonstrates controlling the PiCar-X with keyboard commands - “W” for forward, “S” for
backward, “A” for left turns, and “D” for right turns.


   - **Tilt and Pan of Camera** : Teaches controlling the mounted camera’s tilt and pan using “I” (up), “K” (down), “J”
(left), and “L” (right).


   - **Code Explanation** : Provides a detailed explanation of the Python code for keyboard control, including library
imports and control logic.


   - **Running the Code** : Shows how to execute the Python code for keyboard control, including connecting to the
PiCar-X.


**148** **Chapter 4. Python Video Course**


**SunFounder PiCar-X Kit**


   - **Exiting Control** : Explains exiting keyboard control by pressing “Ctrl + C”, returning the robot to its default
state.


This tutorial is ideal for beginners and robotics enthusiasts, offering clear instructions and a hands-on demonstration
for controlling the PiCar-X robot with a keyboard.


**Video**


**Related On-line Tutorials**


   - _3. Keyboard Control_


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!

### **4.6 Video 3: Text to Speech**


This tutorial covers the text-to-speech features of the PiCar-X robot:


   - **Robot Setup and Initial Movement** : Demonstrates the robot’s readiness and initial movement, including stopping and obstacle detection.


   - **Text-to-Speech Capabilities** : Shows how the robot can speak predefined phrases and count down using text-tospeech technology.


   - **Custom Script Demonstration** : Runs a custom script where the robot talks, moves, reacts to obstacles, and
makes U-turns.


   - **Playing Music** : Teaches how to play music files on the robot using Python scripts.


The lesson offers an in-depth tutorial on integrating text-to-speech functionality into the PiCar-X robot, including
practical demonstrations and code details.


**Video**


**Related On-line Tutorials**


   - _13. Play Music and Sound Effects_


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


**4.6. Video 3: Text to Speech** **149**


**SunFounder PiCar-X Kit**


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!

### **4.7 Video 4: Obstacle Avoidance with Ultrasonic**


This video tutorial covers obstacle avoidance using an ultrasonic sensor in the PiCar-X robot:


   - **Introduction to Ultrasonic Sensor** : Explains how to use the ultrasonic sensor for measuring distance and controlling the car’s movement.


   - **Python Code Walkthrough** : Details the Python code for obstacle avoidance, including variable definitions and
conditional movement logic.


   - **Creating and Running Custom Scripts** : Shows how to write and execute custom scripts for U-turns and obstacle reactions.


   - **Practical Demonstrations** : Provides demonstrations of the robot’s obstacle avoidance capabilities on different
surfaces.


   - **Code Saving and Updating** : Explains how to save and update scripts on the robot.


This lesson offers an essential guide to implementing ultrasonic sensor-based obstacle avoidance in the PiCar-X robot.


**Video**


**Related On-line Tutorials**


   - _4. Obstacle Avoidance_


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!


**150** **Chapter 4. Python Video Course**


**SunFounder PiCar-X Kit**

### **4.8 Video 5: Greyscale Line Tracking**


This video tutorial explores greyscale line tracking using the PiCar-X robot:


   - **Line Detection** : Demonstrates how the robot detects a black line on a white surface using a greyscale sensor,
allowing it to track or drive over the line.


   - **Python Code Explanation** : Explains the Python code involved in line tracking, detailing the import of modules,
creation of objects, and logic for responding to line detection.


   - **Practical Demonstrations** : Provides demonstrations of the robot detecting and following lines on different
surfaces.


   - **Troubleshooting and Tweaking** : Discusses the need for tweaking and fixing the code for better line tracking
performance.


This lesson offers a comprehensive guide on implementing greyscale line tracking in the PiCar-X, including practical
demonstrations, code walkthroughs, and troubleshooting tips.


**Video**


**Related On-line Tutorials**


   - _6. Line Tracking_


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!

### **4.9 Video 6: Cliff Detection**


This tutorial provides essential insights into programming and utilizing cliff detection in the PiCar-X robot.


   - **Introduction** : Explains the use of a grayscale sensor in PiCar-X for cliff detection by measuring surface reflections.


   - **Python Code Walkthrough** : Covers the code for cliff detection, detailing sensor setup, and program logic.


   - **Demonstration and Testing** : Shows the robot detecting cliffs and reacting, with steps on running and testing
the code.


   - **Auto-Start Setup** : Guides on configuring the Raspberry Pi to run the cliff detection script on boot.


   - **Practical Application** : Demonstrates the robot’s response to different surfaces and edges, highlighting its cliff
detection capability.


**4.8. Video 5: Greyscale Line Tracking** **151**


**SunFounder PiCar-X Kit**


**Video**


**Related On-line Tutorials**


   - _5. Cliff Detection_


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!

### **4.10 Video 7: PiCar-X Computer Vision**


This video tutorial focuses on computer vision capabilities in the PiCar-X:


   - **Introduction to Computer Vision** : Teaches how to detect hand movement, fingers, colors, faces, and read QR
codes using the PiCar-X equipped with a camera.


   - **Remote Desktop and Python Code Execution** : Demonstrates using VNC for remote desktop access to the
Raspberry Pi and running Python code for computer vision tasks.


   - **Color Detection and Photo Taking** : Shows how to detect different colors and take photos using camera controls.


   - **QR Code and Face Detection** : Explains how to switch between QR code reading and face detection features.


   - **Object Detection** : Discusses the use of built-in functions from SunFounder’s VI library for object detection.


   - **Viewing Video on Browser and Mobile** : Teaches how to stream the camera feed to a browser or mobile phone,
ensuring they are connected to the same network as the PiCar-X.


   - **Hand Detection** : Covers the use of hand detection feature from the VI library and running corresponding Python
code.


   - **Code Editing and Running** : Demonstrates creating, editing, and running Python scripts for various computer
vision tasks.


This lesson offers a comprehensive guide to exploring computer vision features in the PiCar-X, including practical
demonstrations of color detection, QR code reading, face detection, and hand movement tracking.


**Video**


**Related On-line Tutorials**


   - _7. Computer Vision_


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


**152** **Chapter 4. Python Video Course**


**SunFounder PiCar-X Kit**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!

### **4.11 Video 8: PiCar-X Stares at You**


This tutorial teaches how to use a camera and servo on the PiCar-X robot for object tracking:


   - **Camera-Servo Integration** : Demonstrates connecting a camera with a servo for movement tracking.


   - **Python Code Overview** : Explains the code for controlling the PiCar-X’s camera movements.


   - **Starting Camera & Video Display** : Shows starting the camera and displaying the video feed.


   - **Face Tracking** : Details how the robot tracks a human face, adjusting its camera angles.


   - **Demonstrations** : Includes demonstrations of the robot’s camera following and adjusting to movements.


   - **Video Streaming** : Covers streaming the camera feed to a browser or mobile phone.


This lesson provides a succinct guide on enabling the PiCar-X to track and focus on objects or faces using its camera.


**Video**


**Related On-line Tutorials**


   - _8. Stare at You_


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!


**4.11. Video 8: PiCar-X Stares at You** **153**


**SunFounder PiCar-X Kit**

### **4.12 Video 9: Recording Video**


This tutorial offers a concise yet detailed guide on recording and managing videos using the PiCar-X robot.


   - **Overview** : Teaches how to record HD 1080p videos using the PiCar-X, a Raspberry Pi self-driving robot car kit.


   - **Documentation and Code** : Guides through the PiCar-X documentation for video recording and explains the
Python script for recording control (start, pause, continue, stop).


   - **Remote Desktop Connection** : Demonstrates how to connect remotely to the Raspberry Pi for video recording.


   - **Practical Recording Demonstration** : Shows running the video recording script and operating it through a
remote desktop.


   - **Video Playback** : Illustrates locating and playing back recorded videos to check quality.


   - **Additional Features** : Introduces PiCamera2 GitHub Repository for more recording options like time-lapse and
easy capture.


   - **Simple Video Scripting** : Highlights creating and running basic video recording scripts with different formats
and configurations.


**Video**


**Related On-line Tutorials**


   - _9. Record Video_


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!

### **4.13 Video 10: Bull Fight with PiCar-X**


This tutorial covers using the PiCar-X Robot for a “bullfight” game, focusing on color detection and movement:


   - **Bull Fight Concept** : Uses PiCar-X’s camera to track and follow red color, with pan and tilt control.


   - **Python Code Overview** : Details the programming behind color detection and robotic movements.


   - **Remote Desktop Access** : Demonstrates managing the PiCar-X’s code via remote desktop.


   - **Color Tracking Mechanics** : Explains how the robot tracks red objects, adjusting its movement accordingly.


   - **Demonstration** : Showcases the PiCar-X in action, pursuing a red target.


**154** **Chapter 4. Python Video Course**


**SunFounder PiCar-X Kit**


This lesson provides a comprehensive guide on programming the PiCar-X for a color-tracking game, complete with
code explanations and a live demonstration.


**Video**


**Related On-line Tutorials**


   - _10. Bull Fight_


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!

### **4.14 Video 11: PiCar-X as Video Car**


This tutorial teaches using PiCar-X as a video car with camera control:


   - **Control Mechanics** : Introduces keyboard controls for movement - forward, backward, left, right, and stop.


   - **Video Car Features** : Focuses on using PiCar-X for driving, adjusting speed, turning, and taking pictures.


   - **Python Code Overview** : Briefly explains the Python code for controlling the car and camera.


   - **Remote Desktop and Program Setup** : Shows setting up the car’s program via remote desktop and running it
at startup.


   - **Live Demonstration** : Includes demonstrations of controlling the PiCar-X with keyboard inputs and using its
camera.


   - **Photo Capture and Viewing** : Teaches capturing and viewing photos taken by the PiCar-X.


The lesson provides a concise overview of operating the PiCar-X as a video car, emphasizing hands-on control and
camera usage.


**Video**


**Related On-line Tutorials**


   - _11. Video Car_


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


**4.14. Video 11: PiCar-X as Video Car** **155**


**SunFounder PiCar-X Kit**


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!

### **4.15 Video 12: Treasure Hunt Game**


The tutorial provides an engaging and educational experience in programming and robotics with the PiCar-X.


   - **Overview** : Demonstrates a treasure hunt game where the PiCar-X robot detects and navigates towards randomly
selected colors.


   - **Python Code** : Detailed explanation of the Python code used for color detection, robot movement control, and
text-to-speech announcements.


   - **Gameplay** : The robot moves using keyboard inputs to find and reach a target color, which is announced via
text-to-speech.


   - **Practical Demo** : Shows the robot in action, successfully identifying and moving towards different colors like
red, yellow, and blue.


   - **Game Exit Instructions** : Covers how to safely exit the game, including stopping the robot and shutting down
the camera.


**Video**


**Related On-line Tutorials**


   - _20. Treasure Hunt_


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!


**156** **Chapter 4. Python Video Course**


**SunFounder PiCar-X Kit**

### **4.16 Video 12: Control PiCAR-X Robot Car use mobile app**


The tutorial provides a comprehensive guide on using the mobile app for the Picar-X Raspberry Pi robot from SunFounder.


1. **Overview** : Explains the setup and usage of the SunFounder Picar-X robot car kit, including how to use the
mobile app to control the robot.


2. **Initial Setup** : Demonstrates the initial setup steps, including installing necessary modules and setting up the
PowerShell for SSH access.


3. **App Integration** : Shows how to customize the mobile app interface with various widgets such as button
switches, joysticks, and digital displays.


4. **Python Code Execution** : Guides through the process of running Python scripts to control the robot, including
setting up the IP address and executing the scripts.


5. **Camera Setup** : Explains how to set up and view the camera feed from the robot, ensuring proper connection
and functionality.


6. **App Installation and Configuration** : Details the steps to install and configure the SunFounder controller app,
connect to the robot, and control its movements.


7. **Practical Demonstration** : Provides a hands-on demonstration of controlling the robot using the app, including
moving the camera and navigating the robot.


8. **Debugging and Troubleshooting** : Offers tips on troubleshooting common issues, ensuring smooth operation
and connectivity of the robot and app.


**Video**


**Related On-line Tutorials**


   - _20. Treasure Hunt_


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!


**4.16. Video 12: Control PiCAR-X Robot Car use mobile app** **157**


**SunFounder PiCar-X Kit**


**158** **Chapter 4. Python Video Course**


**CHAPTER**

### **FIVE** **PLAY WITH EZBLOCK**


For beginners and novices, EzBlock is a software development platform offered by SunFounder for Raspberry Pi.
Ezbock offers two programming environments: a graphical environment and a Python environment.


It is available for almost all types of devices, including Mac, PC, and Android.


Here is a tutorial to help you complete EzBlock installation, download, and use.


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!

### **5.1 Quick Guide on EzBlock**


The angle range of the servo is -90~90, but the angle set at the factory is random, maybe 0°, maybe 45°; if we assemble
it with such an angle directly, it will lead to a chaotic state after the robot runs the code, or worse, it will cause the servo
to block and burn out.


So here we need to set all the servo angles to 0° and then install them, so that the servo angle is in the middle, no matter
which direction to turn.


[1. Firstly, Install EzBlock OS (EzBlock’s own tutorials) onto a Micro SD card, once the installation is complete,](https://docs.sunfounder.com/projects/ezblock3/en/latest/quick_guide_3.2/install_ezblock_os.html#install-ezblock-os-latest)
insert it into the Raspberry Pi.


**Note:** After the installation is complete, please return to this page.


**159**


**SunFounder PiCar-X Kit**


2. To ensure that the servo has been properly set to 0°, first insert the servo arm into the servo shaft and then gently
rotate the rocker arm to a different angle. This servo arm is just to allow you to clearly see that the servo is
rotating.


3. Follow the instructions on the assembly foldout, insert the battery cable and turn the power switch to the ON.
Then plug in a powered USB-C cable to activate the battery. Wait for 1-2 minutes, there will be a sound to
indicate that the Raspberry Pi boots successfully.


**160** **Chapter 5. Play with Ezblock**


**SunFounder PiCar-X Kit**


4. Next, plug the servo cable into the P11 port as follows.


5. Press and hold the **USR** key, then press the **RST** key to execute the servo zeroing script within the system. When
you see the servo arm rotate to a position(This is the 0° position, which is a random location and may not be
vertical or parallel.), it indicates that the program has run.


**5.1. Quick Guide on EzBlock** **161**


**SunFounder PiCar-X Kit**


**Note:** This step only needs to be done once; afterward, simply insert other servo wires, and they will
automatically zero.


6. Now, remove the servo arm, ensuring the servo wire remains connected, and do not turn off the power. Then
continue the assembly following the paper assembly instructions.


**Note:**


  - Do not unplug this servo cable before fastening this servo with the servo screw, you can unplug it after fastening.


  - Do not turn the servo while it is powered on to avoid damage; if the servo shaft is inserted at the wrong angle,
pull out the servo and reinsert it.


  - Before assembling each servo, you need to plug the servo cable into P11 and turn on the power to set its angle to
0°.


  - This zeroing function will be disabled if you download a program to the robot later with the EzBlock APP.


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


**162** **Chapter 5. Play with Ezblock**


**SunFounder PiCar-X Kit**


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!

### **5.2 Install and Configure EzBlock Studio**


As soon as the robot is assembled, you will need to carry out some basic operations.


[• Install EzBlock Studio: Download and install EzBlock Studio on your device or use the web-based version.](https://docs.sunfounder.com/projects/ezblock3/en/latest/quick_guide_3.2/install_ezblock_app.html#install-ezblock-app-latest)


**Note:** If you are using the Raspberry Pi 5, please download the Beat version. Have any questions or issues during
using? please don’t hesitate to contact us.


[• Connect the Product and EzBlock: Configure Wi-Fi, Bluetooth and calibrate before use.](https://docs.sunfounder.com/projects/ezblock3/en/latest/quick_guide_3.2/connect_product_ezblock.html#connect-product-ezblock-latest)


[• Open and Run Examples: View or run the related example directly.](https://docs.sunfounder.com/projects/ezblock3/en/latest/quick_guide_3.2/open_run.html#open-run-latest)


**Note:** After you connect the Picar-x, there will be a calibration step. This is because of possible deviations in the
installation process or limitations of the servos themselves, making some servo angles slightly tilted, so you can calibrate
them in this step.


But if you think the assembly is perfect and no calibration is needed, you can also skip this step.


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


**5.2. Install and Configure EzBlock Studio** **163**


**SunFounder PiCar-X Kit**


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!

### **5.3 Calibrate the Car**


After you connect the PiCar-X, there will be a calibration step. This is because of possible deviations in the installation
process or limitations of the servos themselves, making some servo angles slightly tilted, so you can calibrate them in
this step.


But if you think the assembly is perfect and no calibration is needed, you can also skip this step.


**Note:** If you want to recalibrate the robot during use, please follow the steps below.


1. You can open the product detail page by clicking the connect icon in the upper left corner.


2. Click the **Settings** button.


**164** **Chapter 5. Play with Ezblock**


**SunFounder PiCar-X Kit**


3. On this page, you can change the product name, product type, view the app version or calibrate the robot. Once
you click on **Calibrate** you can go to the calibration page.


The calibration steps are as follows:


**5.3. Calibrate the Car** **165**


**SunFounder PiCar-X Kit**


1. Once you get to the calibration page, there will be two prompt points telling you where to calibrate.


**Note:** Calibrating is a micro-adjustment process. It is recommended to take the part off and reassemble it if you click a button to the limit and the part is still off.


2. Click on the left prompt point to calibrate the PiCar-X’s Pan-Tilt(the camera part). By using the two sets of
buttons on the right, you can slowly adjust the Pan-Tilt’s orientation, as well as view their angles. When the
adjustment is complete, click on **Confirm** .


**166** **Chapter 5. Play with Ezblock**


**SunFounder PiCar-X Kit**


3. To calibrate the front wheel orientation, click on the right prompt point. Use the two buttons on the right to get
the front wheel facing straight ahead. When the adjustment is done, click on **Confirm** .


**Projects**


**5.3. Calibrate the Car** **167**


**SunFounder PiCar-X Kit**


This section begins with basic programming functions for the PiCar-X, and continues through to creating more advanced programs in Ezblock Studio. Each tutorial contains TIPS that introduce new functions, allowing users to write
the corresponding program. There is also a complete reference code in the Example section that can be directly used.
We suggest attempting the programming without using the code in the Example sections, and enjoy the fun experience
of overcoming the challenges!


All of the Ezblock projects have been uploaded to Ezblock Studio’s Examples page. From the Examples page, users
can run the programs directly, or edit the examples and save them into the users My Projects folder.


The Examples page allows users to choose between Block or Python language. The projects in this section only explain
[Block language, for an explanation of the Python code, please review this file to help you understand the Python code.](https://github.com/sunfounder/picar-x/blob/v2.0/docs/(EN)%20picarmini.md)


**Basic**


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!

### **5.4 Move**


This first project teaches how to program movement actions for the PiCar-X. In this project, the program will tell the
PiCar-X to execute five actions in order: “forward”, “backward”, “turn left”, “turn right”, and “stop”.


To learn the basic usage of Ezblock Studio, please read through the following two sections:


[• How to Create a New Project?](https://docs.sunfounder.com/projects/ezblock3/en/latest/create_new.html#create-project-latest)


**168** **Chapter 5. Play with Ezblock**


**SunFounder PiCar-X Kit**


**TIPS**


This block will make the PiCar-X move forward at a speed based on a percentage of available power. In the example
below “50” is 50% of power, or half-speed.


This block will make the PiCar-X move backward at a speed based on a percentage of available power.


This block adjusts the orientation of the front wheels. The range is “-45” to ”45”. In the example below, “-30” means
the wheels will turn 30° to the left.


**5.4. Move** **169**


**SunFounder PiCar-X Kit**


This block will cause a timed break between commands, based on milliseconds. In the example below, the PiCar-X
will wait for 1 second (1000 milliseconds) before executing the next command.


This block will bring the PiCar-X to a complete stop.


**EXAMPLE**


**Note:**


[• You can write the program according to the following picture, please refer to the tutorial: How to Create a New](https://docs.sunfounder.com/projects/ezblock3/en/latest/create_new.html#create-project-latest)
[Project?.](https://docs.sunfounder.com/projects/ezblock3/en/latest/create_new.html#create-project-latest)


  - Or find the code with the same name on the **Examples** page of the EzBlock Studio and click **Run** or **Edit** directly.


**170** **Chapter 5. Play with Ezblock**


**SunFounder PiCar-X Kit**


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**5.4. Move** **171**


**SunFounder PiCar-X Kit**


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!

### **5.5 Remote Control**


This project will teach how to remotely control the PiCar-X with the Joystick widget. Note: After dragging and dropping
the Joystick widget from the Remote Control page, use the “Map” function to calibrate the Joysticks X-axis and Y-axis
readings. For more information on the Remote Control function, please reference the following link:


[• How to Use the Remote Control Function?](https://docs.sunfounder.com/projects/ezblock3/en/latest/remote.html#remote-control-latest)


**TIPS**


To use the remote control function, open the Remote Control page from the left side of the main page.


**172** **Chapter 5. Play with Ezblock**


**SunFounder PiCar-X Kit**


Drag a Joystick to the central area of the Remote Control page. Toggling the white point in the center, and gently
dragging in any direction will produce an (X,Y) coordinate. The range of the X-axis or Y-axis is defaulted to “-100”
to “100”. Toggling the white point and dragging it directly to the far left of the Joystick will result in an X value of
“-100” and a Y value of “0”.


After dragging and dropping a widget on the remote control page, a new category-Remote with the above block will
appear. This block reads the Joystick value in the Remote Control page. You can click the drop-down menu to switch
to the Y-axis reading.


The map value block can remap a number from one range to another. If the range is set to 0 to 100, and the map value
number is 50, then it is at a 50% position of the range, or “50”. If the range is set to 0 to 255 and the map value number
is 50, then it is at a 50% position of the range, or “127.5”.


**EXAMPLE**


**Note:**


[• You can write the program according to the following picture, please refer to the tutorial: How to Create a New](https://docs.sunfounder.com/projects/ezblock3/en/latest/create_new.html#create-project-latest)
[Project?.](https://docs.sunfounder.com/projects/ezblock3/en/latest/create_new.html#create-project-latest)


  - Or find the code with the same name on the **Examples** page of the EzBlock Studio and click **Run** or **Edit** directly.


**5.5. Remote Control** **173**


**SunFounder PiCar-X Kit**


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!

### **5.6 Test Ultrasonic Module**


PiCar-X has a built-in Ultrasonic Sensor module that can be used for obstacle avoidance and automatic object-following
experiments. In this lesson the module will read a distance in centimeters (24 cm = 1 inch), and **Print** the results in a
**Debug** window.


**TIPS**


**174** **Chapter 5. Play with Ezblock**


**SunFounder PiCar-X Kit**


The **Ultrasonic get distance** block will read the distance from the PiCar-X to an obstacle directly ahead.


This program is simplified with a **Variable** . For example, when there are multiple functions in a program that each
need to use the distance to an obstacle, a **Variable** can be used to report the same distance value to each function,
instead of each function reading the same value separately.


Click the **Create variable...** button on the **Variables** category, and use the drop-down arrow to select the variable
named “distance”.


The **Print** function can print data such as variables and text for easy debugging.


**5.6. Test Ultrasonic Module** **175**


**SunFounder PiCar-X Kit**


Once the code is running, enable the debug monitor by clicking the **Debug** icon in the bottom left corner.


**EXAMPLE**


**Note:**


[• You can write the program according to the following picture, please refer to the tutorial: How to Create a New](https://docs.sunfounder.com/projects/ezblock3/en/latest/create_new.html#create-project-latest)
[Project?.](https://docs.sunfounder.com/projects/ezblock3/en/latest/create_new.html#create-project-latest)


  - Or find the code with the same name on the **Examples** page of the EzBlock Studio and click **Run** or **Edit** directly.


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


**176** **Chapter 5. Play with Ezblock**


**SunFounder PiCar-X Kit**


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!

### **5.7 Test Grayscale Module**


PiCar-X includes a Grayscale module for implementing line-following, cliff detection, and other fun experiments. The
Grayscale module has three detection sensors that will each report a value according to the shade of color detected by
the sensor. For example, a sensor reading the shade of pure black will return a value of “0”.


**TIPS**


Use the **Grayscale module** block to read the value of one of the sensors. In the example above, the “A0” sensor is the
sensor on the far left of the PiCar-X. Use the drop-down arrow to change the sensor to “A1” (center sensor), or “A2”
(far right sensor).


The program is simplified with a **create list with** block. A **List** is used in the same way as a single **Variable**, but in
this case a **List** is more efficient than a single **Variable** because the **Grayscale module** will be reporting more than one
sensor value. The **create list with** block will create separate **Variables** for each sensor, and put them into a List.


**EXAMPLE**


**Note:**


[• You can write the program according to the following picture, please refer to the tutorial: How to Create a New](https://docs.sunfounder.com/projects/ezblock3/en/latest/create_new.html#create-project-latest)
[Project?.](https://docs.sunfounder.com/projects/ezblock3/en/latest/create_new.html#create-project-latest)


  - Or find the code with the same name on the **Examples** page of the EzBlock Studio and click **Run** or **Edit** directly.


**5.7. Test Grayscale Module** **177**


**SunFounder PiCar-X Kit**


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!

### **5.8 Color Detection**


PiCar-X is a self-driving car with a built-in camera, which allows Ezblock programs to utilize object detection and
color recognition code. In this section, Ezblock will be used to create a program for color detection.


**Note:** Before attempting this section, make sure that the Raspberry Pi Camera’s FFC cable is properly and securely
connected. For detailed instructions on securely connecting the FCC cable, please reference: _Assemble the PiCar-X_ .


In this program, Ezblock will first be told the Hue-Saturation-Value (HSV) space range of the color to be detected, then
utilize OpenCV to process the colors in the HSV range to remove the background noise, and finally, box the matching
color.


Ezblock includes 6 color models for PiCar-X, “red”, “orange”, “yellow”, “green”, “blue”, and “purple”. Color cards
have been prepared in the following PDF, and will need to be printed on a color printer.


   - `[PDF]Color Cards`


**178** **Chapter 5. Play with Ezblock**


**SunFounder PiCar-X Kit**


**Note:** The printed colors may have a slightly different hue from the Ezblock color models due to printer toner differences, or the printed medium, such as a tan-colored paper. This can cause a less accurate color recognition.


**5.8. Color Detection** **179**


**SunFounder PiCar-X Kit**


**TIPS**


Drag the Video widget from the remote Control page, and it will generate a video monitor. For more information on
[how to use the Video widget, please reference the tutorial on Ezblock video here: How to Use the Video Function?.](https://docs.sunfounder.com/projects/ezblock3/en/latest/use_video.html#video-latest)


Enable the video monitor by setting the **camera monitor** block to **on** . Note: Setting the **camera monitor** to **off** will
close the monitor, but object detection will still be available.


Use the **color detection** block to enable the color detection. Note: only one color can be detected at a time.


**180** **Chapter 5. Play with Ezblock**


**SunFounder PiCar-X Kit**


**EXAMPLE**


**Note:**


[• You can write the program according to the following picture, please refer to the tutorial: How to Create a New](https://docs.sunfounder.com/projects/ezblock3/en/latest/create_new.html#create-project-latest)
[Project?.](https://docs.sunfounder.com/projects/ezblock3/en/latest/create_new.html#create-project-latest)


  - Or find the code with the same name on the **Examples** page of the EzBlock Studio and click **Run** or **Edit** directly.


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!

### **5.9 Face Detection**


In addition to color detection, PiCar-X also includes a face detection function. In the following example the Joystick
widget is used to adjust the direction of the camera, and the number of faces will be displayed in the debug monitor.


[For more information on how to use the Video widget, please reference the tutorial on Ezblock video here: How to Use](https://docs.sunfounder.com/projects/ezblock3/en/latest/use_video.html#video-latest)
[the Video Function?.](https://docs.sunfounder.com/projects/ezblock3/en/latest/use_video.html#video-latest)


**5.9. Face Detection** **181**


**SunFounder PiCar-X Kit**


**TIPS**


Set the **face detection** widget to **on** to enable facial detection.


These two blocks are used to adjust the orientation of the pan-tilt camera, similar to driving the PiCar-X in the _Remote_
_Control_ tutorial. As the value increases, the camera will rotate to the right, or upwards, a decreasing value will rotate
the camera right, or downwards.


**182** **Chapter 5. Play with Ezblock**


**SunFounder PiCar-X Kit**


The image detection results are given through the of **detected face** block. Use the drop-down menu options to choose
between reading the coordinates, size, or number of results from the image detection function.


Use the **create text with** block to print the combination of **text** and of **detected face** data.


**EXAMPLE**


**Note:**


[• You can write the program according to the following picture, please refer to the tutorial: How to Create a New](https://docs.sunfounder.com/projects/ezblock3/en/latest/create_new.html#create-project-latest)
[Project?.](https://docs.sunfounder.com/projects/ezblock3/en/latest/create_new.html#create-project-latest)


  - Or find the code with the same name on the **Examples** page of the EzBlock Studio and click **Run** or **Edit** directly.


**5.9. Face Detection** **183**


**SunFounder PiCar-X Kit**


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


**184** **Chapter 5. Play with Ezblock**


**SunFounder PiCar-X Kit**


Ready to explore and create with us? Click [] and join today!

### **5.10 Sound Effect**


PiCar-X has a built-in speaker that can be used for audio experiments. Ezblock allows users to enter text to make the
PiCar-X speak, or make specific sound effects. In this tutorial, the PiCar-X will make the sound of a gun firing after a
3-second countdown, using a do/while function.


**TIPS**


Use the **say** block with a **text** block to write a sentence for the PiCar-X to say. The **say** block can be used with text or
numbers.


The **number** block.


Using the **repeat** block will repeatedly execute the same statement, which reduces the size of the code.


The **mathematical operation** block can perform typical mathematical functions, such as ”+”, “-”, “x”, and “÷ “.


The play **sound effects - with volume - %** block has preset sound effects, such as a siren sound, a gun sound, and
others. The range of the volume can be set from 0 to 100.


**EXAMPLE**


**Note:**


[• You can write the program according to the following picture, please refer to the tutorial: How to Create a New](https://docs.sunfounder.com/projects/ezblock3/en/latest/create_new.html#create-project-latest)
[Project?.](https://docs.sunfounder.com/projects/ezblock3/en/latest/create_new.html#create-project-latest)


**5.10. Sound Effect** **185**


**SunFounder PiCar-X Kit**


  - Or find the code with the same name on the **Examples** page of the EzBlock Studio and click **Run** or **Edit** directly.


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!

### **5.11 Background Music**


In addition to programming the PiCar-X to play sound effects or text-to-speech (TTS), the PiCar-X will also play
background music. This project will also use a **Slider** widget for adjusting the music volume.


[• How to Use the Remote Control Function?](https://docs.sunfounder.com/projects/ezblock3/en/latest/remote.html#remote-control-latest)


For a detailed tutorial on Ezblocks remote control functions, please reference the _Remote Control_ tutorial.


**TIPS**


The **play background music** block will need to be added to the **Start** function. Use the drop-down menu to choose
different background music for the PiCar-X to play.


**186** **Chapter 5. Play with Ezblock**


**SunFounder PiCar-X Kit**


The block **set background music volume to** will adjust the volume between the range of 0 to 100.


Drag a **Slider** bar from the **Remote Control** page to adjust music volume.


The **slider [A] get value** block will read the slider value. The example above has slider ‘A’ selected. If there are multiple
sliders, use the drop-down menu to select the appropriate one.


**EXAMPLE**


**Note:**


[• You can write the program according to the following picture, please refer to the tutorial: How to Create a New](https://docs.sunfounder.com/projects/ezblock3/en/latest/create_new.html#create-project-latest)
[Project?.](https://docs.sunfounder.com/projects/ezblock3/en/latest/create_new.html#create-project-latest)


  - Or find the code with the same name on the **Examples** page of the EzBlock Studio and click **Run** or **Edit** directly.


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


**5.11. Background Music** **187**


**SunFounder PiCar-X Kit**


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!

### **5.12 Say Hello**


This project will combine several functions from the preceding projects. The PiCar-X movement will be remotely
controlled, and the PiCar’s camera will be remotely controlled by using two joystick controllers. When PiCar recognizes
someone’s face, it will nod politely and then say “Hello!”.


[• How to Use the Video Function?](https://docs.sunfounder.com/projects/ezblock3/en/latest/use_video.html#video-latest)


[• How to Use the Remote Control Function?](https://docs.sunfounder.com/projects/ezblock3/en/latest/remote.html#remote-control-latest)


**TIPS**


The **if do** block is used to nod politely once the conditional judgment of “if” is true.


**188** **Chapter 5. Play with Ezblock**


**SunFounder PiCar-X Kit**


The **conditional statements** block is used in conjunction with the **if do** block. The conditions can be “=”, “>”, “<”, ”
“, ” “, or ” “.


**EXAMPLE**


**Note:**


[• You can write the program according to the following picture, please refer to the tutorial: How to Create a New](https://docs.sunfounder.com/projects/ezblock3/en/latest/create_new.html#create-project-latest)
[Project?.](https://docs.sunfounder.com/projects/ezblock3/en/latest/create_new.html#create-project-latest)


  - Or find the code with the same name on the **Examples** page of the EzBlock Studio and click **Run** or **Edit** directly.


**5.12. Say Hello** **189**


**SunFounder PiCar-X Kit**


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**190** **Chapter 5. Play with Ezblock**


**SunFounder PiCar-X Kit**


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!

### **5.13 Music Car**


This project will turn the PiCar-X into a music car that will travel around your home, playing cheerful music. This
project will also show how the PiCar-X avoids hitting walls with the built-in ultrasonic sensor.


**TIPS**


To implement multiple conditional judgments, change the simple if do block into an if else do / else if do block. This
is done by clicking on the setting icon as shown above.


**EXAMPLE**


**Note:**


[• You can write the program according to the following picture, please refer to the tutorial: How to Create a New](https://docs.sunfounder.com/projects/ezblock3/en/latest/create_new.html#create-project-latest)
[Project?.](https://docs.sunfounder.com/projects/ezblock3/en/latest/create_new.html#create-project-latest)


  - Or find the code with the same name on the **Examples** page of the EzBlock Studio and click **Run** or **Edit** directly.


**5.13. Music Car** **191**


**SunFounder PiCar-X Kit**


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!

### **5.14 Cliff Detection**


This project will use the **grayscale module** to prevent the PiCar-X from falling off a cliff while it is moving freely
around your home. This is an essential project for houses with staircases.


**TIPS**


**192** **Chapter 5. Play with Ezblock**


**SunFounder PiCar-X Kit**


The **grayscale module** will be performing the same operation multiple times. To simplify the program, this project
introduces a **function** that will return a **list** variable to the **do forever** block.


**EXAMPLE**


**Note:**


[• You can write the program according to the following picture, please refer to the tutorial: How to Create a New](https://docs.sunfounder.com/projects/ezblock3/en/latest/create_new.html#create-project-latest)
[Project?.](https://docs.sunfounder.com/projects/ezblock3/en/latest/create_new.html#create-project-latest)


  - Or find the code with the same name on the **Examples** page of the EzBlock Studio and click **Run** or **Edit** directly.


**5.14. Cliff Detection** **193**


**SunFounder PiCar-X Kit**


**194** **Chapter 5. Play with Ezblock**


**SunFounder PiCar-X Kit**


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!


**5.14. Cliff Detection** **195**


**SunFounder PiCar-X Kit**

### **5.15 Minecart**


Let’s make a minecart project! This project will use the Grayscale module to make the PiCar-X move forward along a
track. Use dark-colored tape to make a track on the ground as straight as possible, and not too curved. Some experimenting might be needed if the PiCar-X becomes derailed.


When moving along the track, the probes on the left and right sides of the Grayscale module will detect light-colored
ground, and the middle probe will detect the track. If the track has an arc, the probe on the left or right side of the
sensor will detect the dark-colored tape, and turn the wheels in that direction. If the minecart reaches the end of the
track or derails, the Grayscale module will no longer detect the dark-colored tape track, and the PiCar-X will come to
a stop.


**TIPS**


   - **Set ref to ()** block is used to set the grayscale threshold, you need to modify it according to the actual situation.
You can go ahead and run _Test Grayscale Module_ to see the values of the grayscale module on the white and
black surfaces, and fill in their middle values in this block.


**EXAMPLE**


**Note:**


[• You can write the program according to the following picture, please refer to the tutorial: How to Create a New](https://docs.sunfounder.com/projects/ezblock3/en/latest/create_new.html#create-project-latest)
[Project?.](https://docs.sunfounder.com/projects/ezblock3/en/latest/create_new.html#create-project-latest)


  - Or find the code with the same name on the **Examples** page of the EzBlock Studio and click **Run** or **Edit** directly.


**196** **Chapter 5. Play with Ezblock**


**SunFounder PiCar-X Kit**


**5.15. Minecart** **197**


**SunFounder PiCar-X Kit**


**198** **Chapter 5. Play with Ezblock**


**SunFounder PiCar-X Kit**


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!


**5.15. Minecart** **199**


**SunFounder PiCar-X Kit**

### **5.16 Minecart Plus**


In this project, derailment recovery has been added to the _Minecart_ project to let the PiCar-X adapt and recover from
a more severe curve.


**TIPS**


1. Use another **to do something** block to allow the PiCar-X to back up and recover from a sharp curve. Note that
the new **to do something** function does not return any values, but is used just for reorienting the PiCar-X.


2. **Set ref to ()** block is used to set the grayscale threshold, you need to modify it according to the actual situation.
You can go ahead and run _Test Grayscale Module_ to see the values of the grayscale module on the white and
black surfaces, and fill in their middle values in this block.


**EXAMPLE**


**Note:**


[• You can write the program according to the following picture, please refer to the tutorial: How to Create a New](https://docs.sunfounder.com/projects/ezblock3/en/latest/create_new.html#create-project-latest)
[Project?.](https://docs.sunfounder.com/projects/ezblock3/en/latest/create_new.html#create-project-latest)


  - Or find the code with the same name on the **Examples** page of the EzBlock Studio and click **Run** or **Edit** directly.


**200** **Chapter 5. Play with Ezblock**


**SunFounder PiCar-X Kit**


**5.16. Minecart Plus** **201**


**SunFounder PiCar-X Kit**


**202** **Chapter 5. Play with Ezblock**


**SunFounder PiCar-X Kit**


**5.16. Minecart Plus** **203**


**SunFounder PiCar-X Kit**


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!


**204** **Chapter 5. Play with Ezblock**


**SunFounder PiCar-X Kit**

### **5.17 Bullfight**


Turn PiCar-X into an angry bull! Prepare a red cloth, such as a handkerchief, and become a Bullfighter. When the
PiCar-X chases after the red cloth, be careful not to get hit!


**Note:** This project is more advanced than the preceding projects. The PiCar-X will need to use the color detection
function to keep the camera facing towards the red cloth, then the body orientation will need to automatically adjust in
response to the direction that the camera is facing.


**TIPS**


Begin with adding the **color detection [red]** block to the **Start** widget to make the PiCar-X look for a red-colored
object. In the forever loop, add the **[width] of detected color** block to transform the input into an “object detection”
grid.


The “object detection” will output the detected coordinates in (x, y) values, based on the center point of the camera
image. The screen is divided into a 3x3 grid, as shown below, so if the red cloth is kept in the top left of the cameras’
image, the (x, y) coordinates will be (-1, 1).


The “object detection” will detect the Width and Height of the graphic. If multiple targets are identified, the dimensions
of the largest target will be recorded.


**5.17. Bullfight** **205**


**SunFounder PiCar-X Kit**


**EXAMPLE**


**Note:**


[• You can write the program according to the following picture, please refer to the tutorial: How to Create a New](https://docs.sunfounder.com/projects/ezblock3/en/latest/create_new.html#create-project-latest)
[Project?.](https://docs.sunfounder.com/projects/ezblock3/en/latest/create_new.html#create-project-latest)


  - Or find the code with the same name on the **Examples** page of the EzBlock Studio and click **Run** or **Edit** directly.


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


**206** **Chapter 5. Play with Ezblock**


**SunFounder PiCar-X Kit**


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!

### **5.18 Beware of Pedestrians**


This project will make the PiCar-X perform appropriate measures based on road conditions. While driving, the PiCar-X
will come to a complete stop if a pedestrian is detected in its path.


Once the program is running, hold a photo of a person in front of the PiCar-X. The Video Monitor will detect the
person’s face, and the PiCar-X will automatically come to a stop.


To simulate driving safety protocols, a judgment procedure is created that will send a **[count]** value to a **if do else** block.
The judgement procedure will look for a human face 10 times, and if a face does appear it will increment **[count]** by
+1. When **[count]** is larger than 3, the PiCar-X will stop moving.


[• How to Use the Remote Control Function?](https://docs.sunfounder.com/projects/ezblock3/en/latest/remote.html#remote-control-latest)


**EXAMPLE**


**5.18. Beware of Pedestrians** **207**


**SunFounder PiCar-X Kit**


**Note:**


[• You can write the program according to the following picture, please refer to the tutorial: How to Create a New](https://docs.sunfounder.com/projects/ezblock3/en/latest/create_new.html#create-project-latest)
[Project?.](https://docs.sunfounder.com/projects/ezblock3/en/latest/create_new.html#create-project-latest)


  - Or find the code with the same name on the **Examples** page of the EzBlock Studio and click **Run** or **Edit** directly.


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


**208** **Chapter 5. Play with Ezblock**


**SunFounder PiCar-X Kit**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!

### **5.19 Traffic Sign Detection**


In addition to color, face detection, PiCar-X can also do traffic sign detection.


Now let’s combine this traffic sign detection with the line following function. Let PiCar-X track the line, and when
you put the Stop sign in front of it, it will stop. When you place a Forward sign in front of it, it will continue to move
forward.


**TIPS**


1. PiCar will recognize 4 different traffic sign models included in the printable PDF below.


        - `[PDF]Traffic Sign Cards`


2. **Set ref to ()** block is used to set the grayscale threshold, you need to modify it according to the actual situation.
You can go ahead and run _Test Grayscale Module_ to see the values of the grayscale module on the white and
black surfaces, and fill in their middle values in this block.


**EXAMPLE**


**Note:**


[• You can write the program according to the following picture, please refer to the tutorial: How to Create a New](https://docs.sunfounder.com/projects/ezblock3/en/latest/create_new.html#create-project-latest)
[Project?.](https://docs.sunfounder.com/projects/ezblock3/en/latest/create_new.html#create-project-latest)


**5.19. Traffic Sign Detection** **209**


**SunFounder PiCar-X Kit**


  - Or find the code with the same name on the **Examples** page of the EzBlock Studio and click **Run** or **Edit** directly.


**210** **Chapter 5. Play with Ezblock**


**SunFounder PiCar-X Kit**


**5.19. Traffic Sign Detection** **211**


**SunFounder PiCar-X Kit**


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!


**212** **Chapter 5. Play with Ezblock**


**SunFounder PiCar-X Kit**

### **5.20 Orienteering**


This project uses the remote control function to guide the PiCar-X through a competitive scavenger hunt!


First, set up either an obstacle course, or a maze, or even an empty room that the PiCar-X can drive through. Then,
randomly place six markers along the route, and put a color-card at each of the six markers for the PiCar-X to find.


The six color models for PiCar-X are: red, orange, yellow, green, blue and purple, and are ready to print from a colored
printer from the PDF below.


   - `[PDF]Color Cards`


**Note:** The printed colors may have a slightly different hue from the Ezblock color models due to printer toner differences, or the printed medium, such as a tan-colored paper. This can cause a less accurate color recognition.


The PiCar-X will be programmed to find three of the six colors in a random order, and will be using the TTS function
to announce which color to look for next.


The objective is to help the PiCar-X find each of the three colors in as short of a time as possible.


Place PiCar-X in the middle of the field and click the Button on the Remote Control page to start the game.


**5.20. Orienteering** **213**


**SunFounder PiCar-X Kit**


Take turns playing this game with friends to see who can help PiCar-X complete the objective the fastest!


**EXAMPLE**


**Note:**


[• You can write the program according to the following picture, please refer to the tutorial: How to Create a New](https://docs.sunfounder.com/projects/ezblock3/en/latest/create_new.html#create-project-latest)
[Project?.](https://docs.sunfounder.com/projects/ezblock3/en/latest/create_new.html#create-project-latest)


  - Or find the code with the same name on the **Examples** page of the EzBlock Studio and click **Run** or **Edit** directly.


**214** **Chapter 5. Play with Ezblock**


**SunFounder PiCar-X Kit**


**5.20. Orienteering** **215**


**SunFounder PiCar-X Kit**


**216** **Chapter 5. Play with Ezblock**


**SunFounder PiCar-X Kit**


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!


**5.20. Orienteering** **217**


**SunFounder PiCar-X Kit**


**218** **Chapter 5. Play with Ezblock**


**CHAPTER**

### **SIX** **ADJUST SERVO FOR ASSEMBLY**


Before assembling the servo, it is essential to set the angle to zero. Since servo motors have a limited range of motion,
setting the angle to zero degrees ensures that the servo starts in its initial position and avoids exceeding its range when
powered on. Failing to set the servo to zero beforehand may cause it to attempt to move beyond its allowed range
when powered, potentially damaging both the servo and the mechanical system it’s attached to. This step is crucial to
guarantee safe and proper operation of the servo motor.


**219**


**SunFounder PiCar-X Kit**

### **6.1 For Python Users**


Refer to _1. Quick Guide on Python_ to complete the installation of Raspberry Pi OS and adjust the servo angles.

### **6.2 For Ezblock Users**


**Note:** If you are using a Raspberry Pi 5, our graphical programming software, EzBlock, is not supported.


Once you have installed the Ezblock system, the P11 pin can be used to adjust the servo. For more details, please refer
to _Quick Guide on EzBlock_ .


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!


**220** **Chapter 6. Adjust Servo for Assembly**


**CHAPTER**

### **SEVEN** **APPENDIX**


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!

### **7.1 I [2] C Configuration**


Follow the steps below to enable and test the I [2] C interface on your Raspberry Pi. These instructions apply to Raspberry
Pi 5, 4, 3, and Zero 2W.


**7.1.1 Enable the I** **[2]** **C Interface**


1. Open a terminal on your computer (Windows: **PowerShell** ; macOS/Linux: **Terminal** ) and connect to your
Raspberry Pi:

```
   ssh <username>@<hostname>.local

```

or:

```
   ssh <username>@<ip_address>

```

2. Open the Raspberry Pi configuration tool:

```
   sudo raspi-config

```

3. Select **Interfacing Options** and press **Enter** .


**221**


**SunFounder PiCar-X Kit**


4. Select **I2C** .


5. Choose **<Yes>**, then **<Ok>** _→_ **<Finish>** to apply the changes. If prompted, reboot your Raspberry Pi.


**222** **Chapter 7. Appendix**


**SunFounder PiCar-X Kit**



**7.1.2 Check I** **[2]** **C Kernel Modules**


1. Run the following command:

```
   lsmod | grep i2c

```

2. If I [2] C is enabled, you will see modules such as:





3. If nothing appears, reboot the system:

```
   sudo reboot

```

**7.1.3 Install i2c-tools**


1. Install the utilities required for scanning and testing I [2] C devices:

```
   sudo apt install i2c-tools

```

**7.1. I** **[2]** **C Configuration** **223**


**SunFounder PiCar-X Kit**


**7.1.4 Detect Connected I** **[2]** **C Devices**


1. Scan the I [2] C bus:

```
   i2cdetect -y 1

```

2. Example output:

```
   pi@raspberrypi ~ $ i2cdetect -y 1
     0 1 2 3 4 5 6 7 8 9 a b c d e f
   00: -- -- -- -- -- -- -- -- -- -- -- -- -   10: -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -   20: -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -   30: -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -   40: -- -- -- -- -- -- -- -- 48 -- -- -- -- -- -- -   50: -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -   60: -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -   70: -- -- -- -- -- -- -- -
```

3. If a device is connected, its address (e.g., **0x48** ) will appear in the table.


**7.1.5 Install the Python I** **[2]** **C Library**


1. Install the `python3-smbus2` package:

```
   sudo apt install python3-smbus2

```

The `smbus2` library provides all the functions required to communicate with I [2] C devices in Python.


Your Raspberry Pi is now fully configured and ready to communicate with I [2] C devices.


**Note:** Hello, welcome to the SunFounder Raspberry Pi, Arduino, and ESP32 Enthusiasts Community on Facebook!
Join fellow makers to explore, learn, and create together.


**Why Join?**


   - **Expert Support**   - Get help with post-sale issues and technical challenges.


   - **Learn & Share**   - Exchange tutorials, tips, and hands-on experiences.


   - **Exclusive Previews**   - Get early access to new product announcements.


   - **Special Discounts**   - Enjoy members-only offers on new products.


   - **Giveaways & Events**   - Join festive promotions and prize draws.


Click to join the community!


**224** **Chapter 7. Appendix**


**SunFounder PiCar-X Kit**

### **7.2 SPI Configuration**


Follow the steps below to enable and verify the SPI interface on your Raspberry Pi. These instructions apply to Raspberry Pi 5, 4, 3, and Zero 2W.


**7.2.1 Enable the SPI Interface**


1. Open a terminal on your computer (Windows: **PowerShell** ; macOS/Linux: **Terminal** ) and connect to your
Raspberry Pi:

```
   ssh <username>@<hostname>.local

```

or:

```
   ssh <username>@<ip_address>

```

2. Open the Raspberry Pi configuration tool:

```
   sudo raspi-config

```

3. Select **Interfacing Options** and press **Enter** .


4. Select **SPI** .


**7.2. SPI Configuration** **225**


**SunFounder PiCar-X Kit**


5. Choose **<Yes>**, then **<Ok>** _→_ **<Finish>** to apply the changes. If prompted, reboot your Raspberry Pi.


**226** **Chapter 7. Appendix**


**SunFounder PiCar-X Kit**



**7.2.2 Verify SPI Interface**


1. Check whether the SPI device nodes exist:

```
   ls /dev/sp*

```

2. If the SPI interface is enabled, the output will include:






     - If these devices appear, SPI is active and ready to use.


     - If not, reboot your Raspberry Pi and check again.


**7.2.3 Install spidev (Python SPI Library)**


1. Install the `spidev` package to use SPI in Python:

```
   sudo apt install python3-spidev

```

The `spidev` library provides access to SPI devices through the `/dev/spidevX.Y` interface.


Your Raspberry Pi is now configured to communicate with SPI devices using both command-line tools and Python.


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!

### **7.3 Remote Desktop**


You can access and control the Raspberry Pi desktop remotely from another computer. The recommended method is
**VNC**, which is officially supported on Raspberry Pi OS and provides a reliable and consistent desktop experience.


The following section explains how to enable VNC on your Raspberry Pi and connect to it using .


**7.3. Remote Desktop** **227**


**SunFounder PiCar-X Kit**


**7.3.1 Enable the VNC Service**


RealVNC Server is preinstalled on Raspberry Pi OS, but it is **disabled by default** . You must enable it through the
configuration tool.


1. Open a terminal on your computer (Windows: **PowerShell** ; macOS/Linux: **Terminal** ) and connect to your
Raspberry Pi:

```
   ssh <username>@<hostname>.local

```

or

```
   ssh <username>@<ip_address>

```

2. Run the configuration tool:

```
   sudo raspi-config

```

3. Select **Interfacing Options** and press **Enter** .


**228** **Chapter 7. Appendix**


**SunFounder PiCar-X Kit**


4. Select **VNC** .


5. Choose **Yes**, then **OK**, and finally **Finish** to exit.


**7.3. Remote Desktop** **229**


**SunFounder PiCar-X Kit**


**7.3.2 Log in with RealVNC® Viewer**


1. Download and install for your operating system.


2. Open **RealVNC Viewer**, then enter your Raspberry Pi’s IP address or `<hostname>.local` and press **Enter** .


**230** **Chapter 7. Appendix**


**SunFounder PiCar-X Kit**


3. Enter your Raspberry Pi’s **username** and **password**, then select **OK** .


**Note:** When connecting for the first time, you may see a message such as “VNC Server not recognized”. Select
**Continue** to proceed.


**7.3. Remote Desktop** **231**


**SunFounder PiCar-X Kit**


4. You should now see the Raspberry Pi desktop:


**232** **Chapter 7. Appendix**


**SunFounder PiCar-X Kit**


This completes the VNC setup process.


**7.3.3 Additional Notes**


   - **Desktop version required**


**–** VNC requires the Raspberry Pi to be running the full desktop version of Raspberry Pi OS.


**–** If you are using **Raspberry Pi OS Lite**, install VNC Server manually: `sudo apt install`
```
     realvnc-vnc-server

```

   - **Network performance tips**


**–** If you experience lag or slow refresh rates, check your network quality.


**–** Wired Ethernet generally offers the best performance.


   - **Fixing display resolution issues**


**–** If the VNC window appears too small or the resolution is incorrect, set a fixed resolution via: `sudo`
`raspi-config` _→_ **Display Options** _→_ **VNC Resolution**


   - **Ensure VNC is enabled**


If VNC fails to connect, verify that it is enabled in: `sudo raspi-config` _→_ `Interfacing Options` _→_ `VNC`


**7.3. Remote Desktop** **233**


**SunFounder PiCar-X Kit**


   - **Stopping the VNC service**


To manually stop the VNC Server: `sudo systemctl stop vncserver-x11-serviced`


   - **Security reminder**


**–** VNC is designed for trusted local networks.


**–** Do **not** expose VNC directly to the internet.


**–** For secure remote access from outside your network, use **Raspberry Pi Connect** or a VPN.


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!

### **7.4 FileZilla Software**


File Transfer Protocol (FTP) is commonly used to transfer files between computers over a network. **FileZilla** is an
open-source client that supports FTP, FTPS, and **SFTP** (recommended for Raspberry Pi). With FileZilla, you can
easily upload files (such as images, audio, and scripts) from your computer to the Raspberry Pi, or download files from
the Pi back to your computer.


**7.4.1 Download FileZilla**


1. Visit the official website and download **FileZilla Client** for your operating system.


2. Install and launch the program.


**234** **Chapter 7. Appendix**


**SunFounder PiCar-X Kit**


3. Open FileZilla and enter the following information:


      - **Host:** `<hostname>.local` or the Raspberry Pi’s IP address


      - **Username:** your Pi username


      - **Password:** the password set in Raspberry Pi Imager


      - **Port:** `22` (for SFTP)


     - Click **Quickconnect** (or press **Enter** ) to establish a connection.


4. Once connected, the left panel shows your **local files**, and the right panel shows the **Raspberry Pi files** .


**7.4. FileZilla Software** **235**


**SunFounder PiCar-X Kit**


5. You can:


      - **Upload** a file: drag from the left panel _→_ right panel


      - **Download** a file: drag from the right panel _→_ left panel


FileZilla will immediately start the transfer, and the status will appear in the panel at the bottom.


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!


**236** **Chapter 7. Appendix**


**SunFounder PiCar-X Kit**

### **7.5 Install OpenSSH via PowerShell**


If you see the following error when running `ssh <username>@<hostname>.local` or `ssh <username>@<IP>` :



It means your Windows system does not have OpenSSH installed. Follow the steps below to install it manually.


1. Open the Windows Start Menu, type **powershell**, right-click **Windows PowerShell**, and select **Run as admin-**
**istrator** .


2. Install the OpenSSH Client:

```
   Add-WindowsCapability -Online -Name OpenSSH.Client~~~~0.0.1.0

```

3. After installation, you should see output similar to:





4. Verify the installation:

```
 Get-WindowsCapability -Online | Where-Object Name -like 'OpenSSH*'

```

5. If OpenSSH is installed, the output will include:





**Warning:** If `Installed` does not appear, your Windows system may be too old. In this case, we recommend
using a third-party SSH tool. See: _PuTTY_


6. Close PowerShell, reopen it (no need to run as administrator this time), and use the `ssh` command to log in:

```
   ssh <username>@<hostname>.local

```

**7.5. Install OpenSSH via PowerShell** **237**


**SunFounder PiCar-X Kit**


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!

### **7.6 PuTTY**


PuTTY is a simple and reliable SSH client for Windows users to remotely access the Raspberry Pi.


1. Download PuTTY from and install it on your computer.


**238** **Chapter 7. Appendix**


**SunFounder PiCar-X Kit**


2. Open PuTTY and prepare the connection:


     - Enter your Raspberry Pi’s **hostname or IP address** in **Host Name** .


     - Set the **Port** to `22` .


     - Click **Open** to connect.


3. If a security warning appears on first use, click **Accept** to continue.


**7.6. PuTTY** **239**


**SunFounder PiCar-X Kit**


4. Log in to the Raspberry Pi:


    - When you see **login as:**, enter the username you set in **Raspberry Pi Imager** .


     - Enter your password (it will not appear while typing—this is normal).


     - After logging in, the terminal is ready for you to enter commands and operate your Raspberry Pi remotely.


**Note:** If PuTTY shows **inactive**, the connection was lost and needs to be reconnected.


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


**240** **Chapter 7. Appendix**


**SunFounder PiCar-X Kit**


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!


**7.6. PuTTY** **241**


**SunFounder PiCar-X Kit**


**242** **Chapter 7. Appendix**


**CHAPTER**

### **EIGHT** **HARDWARE**


When you are writing code, you may need to know how each module works or the role of each pin, then please see this
chapter.


In this chapter you will find a description of each module’s function, technical parameters and working principle.


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!

### **8.1 Robot HAT**


is a multifunctional expansion board that allows Raspberry Pi to be quickly turned into a robot. An MCU is on board
to extend the PWM output and ADC input for the Raspberry Pi, as well as a motor driver chip, I2S audio module and
mono speaker. As well as the GPIOs that lead out of the Raspberry Pi itself.


It also comes with a Speaker, which can be used to play background music, sound effects and implement TTS functions
to make your project more interesting.


Accepts 7-12V power input with 2 battery indicators, 1 charge indicator and 1 power indicator. The board also has a
user available LED and a button for you to quickly test some effects.


For detailed instructions, please refer to: .


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


**243**


**SunFounder PiCar-X Kit**


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!

### **8.2 Camera Module**


**Description**


This is a 5MP Raspberry Pi camera module with OV5647 sensor. It’s plug and play, connect the included ribbon cable
to the CSI (Camera Serial Interface) port on your Raspberry Pi and you’re ready to go.


The board is small, about 25mm x 23mm x 9mm, and weighs 3g, making it ideal for mobile or other size and weightcritical applications. The camera module has a native resolution of 5 megapixels and has an on-board fixed focus lens
that captures still images at 2592 x 1944 pixels, and also supports 1080p30, 720p60 and 640x480p90 video.


**Note:** The module is only capable of capturing pictures and videos, not sound.


**Specification**


   - **Static Images Resolution** : 2592×1944


   - **Supported Video Resolution** : 1080p/30 fps, 720p/ 60fps and 640 x480p 60/90 video recording


   - **Aperture (F)** : 1.8


   - **Visual Angle** : 65 degree


   - **Dimension** : 24mmx23.5mmx8mm


   - **Weight** : 3g


   - **Interface** : CSI connector


   - **Supported OS** : Raspberry Pi OS(latest version recommended)


**Assemble the Camera Module**


On the camera module or Raspberry Pi, you will find a flat plastic connector. Carefully pull out the black fixing switch
until the fixing switch is partially pulled out. Insert the FFC cable into the plastic connector in the direction shown and
push the fixing switch back into place.


**244** **Chapter 8. Hardware**


**SunFounder PiCar-X Kit**


If the FFC wire is installed correctly, it will be straight and will not pull out when you gently pull on it. If not, reinstall
it again.


**Warning:** Do not install the camera with the power on, it may damage your camera.


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!


**8.2. Camera Module** **245**


**SunFounder PiCar-X Kit**

### **8.3 Ultrasonic Module**


   - **TRIG** : Trigger Pulse Input


   - **ECHO** : Echo Pulse Output


   - **GND** : Ground


   - **VCC** : 5V Supply


This is the HC-SR04 ultrasonic distance sensor, providing non-contact measurement from 2 cm to 400 cm with a range
accuracy of up to 3 mm. Included on the module is an ultrasonic transmitter, a receiver and a control circuit.


You only need to connect 4 pins: VCC (power), Trig (trigger), Echo (receive) and GND (ground) to make it easy to use
for your measurement projects.


**Features**


  - Working Voltage: DC5V


  - Working Current: 16mA


  - Working Frequency: 40Hz


  - Max Range: 500cm


  - Min Range: 2cm


  - Trigger Input Signal: 10uS TTL pulse


  - Echo Output Signal: Input TTL lever signal and the range in proportion


  - Connector: XH2.54-4P


  - Dimension: 46x20.5x15 mm


**Principle**


The basic principles are as follows:


  - Using IO trigger for at least 10us high level signal.


  - The module sends an 8 cycle burst of ultrasound at 40 kHz and detects whether a pulse signal is received.


**246** **Chapter 8. Hardware**


**SunFounder PiCar-X Kit**


  - Echo will output a high level if a signal is returned; the duration of the high level is the time from emission to
return.


  - Distance = (high level time x velocity of sound (340M/S)) / 2


Formula:


  - us / 58 = centimeters distance


  - us / 148 = inch distance


  - distance = high level time x velocity (340M/S) / 2


**Application Notes**


  - This module should not be connected under power up, if necessary, let the module’s GND be connected first.
Otherwise, it will affect the work of the module.


  - The area of the object to be measured should be at least 0.5 square meters and as flat as possible. Otherwise, it
will affect results.


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!


**8.3. Ultrasonic Module** **247**


**SunFounder PiCar-X Kit**

### **8.4 3-pin Battery**


   - **VCC** : Battery positive terminal, here there are two sets of VCC and GND is to increase the current and reduce
the resistance.


   - **Middle** : To balance the voltage between the two cells and thus protect the battery.


   - **GND** : Negative battery terminal.


This is a custom battery pack made by SunFounder consisting of two 18650 batteries with a capacity of 2000mAh. The
connector is XH2.54 3P, which can be charged directly after being inserted into the Robot HAT.


**Features**


  - Composition: Li-ion


  - Battery Capacity: 2000mAh, 14.8Wh


  - Battery Weight: 90.8g


  - Number of Cells: 2


**248** **Chapter 8. Hardware**


**SunFounder PiCar-X Kit**


  - Connector: XH2.54 3P


  - Over-discharge protection: 6.0V


**Note:** Hello, welcome to the SunFounder Raspberry Pi & Arduino & ESP32 Enthusiasts Community on Facebook!
Dive deeper into Raspberry Pi, Arduino, and ESP32 with fellow enthusiasts.


**Why Join?**


   - **Expert Support** : Solve post-sale issues and technical challenges with help from our community and team.


   - **Learn & Share** : Exchange tips and tutorials to enhance your skills.


   - **Exclusive Previews** : Get early access to new product announcements and sneak peeks.


   - **Special Discounts** : Enjoy exclusive discounts on our newest products.


   - **Festive Promotions and Giveaways** : Take part in giveaways and holiday promotions.


Ready to explore and create with us? Click [] and join today!


**8.4. 3-pin Battery** **249**


**SunFounder PiCar-X Kit**


**250** **Chapter 8. Hardware**


**CHAPTER**

### **NINE** **FAQ** **9.1 Q1: After installing Ezblock OS, the servo can’t turn to 0°?**


1) Check if the servo cable is properly connected and if the Robot HAT power is on.


2) Press Reset button.


3) If you have already run the program in Ezblock Studio, the custom program for P11 is no longer available. You
can refer to the picture below to manually write a program in Ezblock Studio to set the servo angle to 0.


**251**


**SunFounder PiCar-X Kit**

### **9.2 Q2: When using VNC, I am prompted that the desktop cannot be** **displayed at the moment?**


In Terminal, type `sudo raspi-config` to change the resolution.

### **9.3 Q3: Why does the servo sometimes return to the middle position** **for no reason?**


When the servo is blocked by a structure or other object and cannot reach its intended position, the servo will enter the
power-off protection mode in order to prevent the servo from being burned out by too much current.


After a period of power failure, if no PWM signal is given to the servo, the servo will automatically return to its original
position.

### **9.4 Q4: About the Robot HAT Detailed Tutorial?**


You can find a comprehensive tutorial about the Robot HAT here, including information on its hardware and API.


   
### **9.5 Q5: About the Battery Charger?**


To charge the battery, simply connect a 5V/2A Type-C power supply to the Robot Hat’s power port. There’s no need
to turn on the Robot Hat’s power switch during charging. You can also use the device while charging the battery.


**252** **Chapter 9. FAQ**


**SunFounder PiCar-X Kit**


During charging, the input power is boosted by the charging chip to charge the battery and simultaneously supply
the DC-DC converter for external use, with a charging power of approximately 10W. If external power consumption
remains high for an extended period, the battery may supplement the power supply, similar to using a phone while
charging. However, be mindful of the battery’s capacity to avoid completely depleting it during simultaneous charging
and usage.

### **9.6 Q6: Camera Not Working?**


If the camera is not displaying or displaying incorrectly, follow these troubleshooting steps:


1. Ensure the FPC cable of the camera is securely connected. It is recommended to reconnect the camera and then
power on the device.


2. Use the following command to check if the camera is recognized.

```
libcamera-hello

```

**9.6. Q6: Camera Not Working?** **253**


**SunFounder PiCar-X Kit**


**254** **Chapter 9. FAQ**


**CHAPTER**

### **TEN** **COPYRIGHT NOTICE**


All contents including but not limited to texts, images, and code in this manual are owned by the SunFounder Company.
You should only use it for personal study,investigation, enjoyment, or other non-commercial or nonprofit purposes,
under therelated regulations and copyrights laws, without infringing the legal rights of the author and relevant right
holders. For any individual or organization that uses these for commercial profit without permission, the Company
reserves the right to take legal action.


**255**


