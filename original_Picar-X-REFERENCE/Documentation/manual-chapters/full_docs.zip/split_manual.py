#!/usr/bin/env python3
"""
Split PiCar-X manual markdown into separate chapter files.
This makes it easier for LLMs to process specific sections.
"""

import re
import os
from pathlib import Path

def split_markdown_by_chapters(input_file: str, output_dir: str):
    """
    Split a markdown file into separate files by main chapters.

    Chapters are detected by patterns like: ### **ONE** **TITLE**
    """

    # Read the markdown file
    with open(input_file, 'r', encoding='utf-8') as f:
        content = f.read()

    # Create output directory
    output_path = Path(output_dir)
    output_path.mkdir(exist_ok=True)

    # Pattern to match main chapter headings like: ### **ONE** **ASSEMBLE THE PICAR-X**
    chapter_pattern = r'^### \*\*(ONE|TWO|THREE|FOUR|FIVE|SIX|SEVEN|EIGHT|NINE|TEN)\*\* \*\*(.+?)\*\*'

    # Find all chapter positions
    lines = content.split('\n')
    chapters = []

    # First, extract header content (before first chapter)
    header_end = 0

    for i, line in enumerate(lines):
        match = re.match(chapter_pattern, line)
        if match:
            chapter_num = match.group(1)
            chapter_title = match.group(2).strip('*').strip()
            chapters.append({
                'number': chapter_num,
                'title': chapter_title,
                'start_line': i,
                'end_line': None
            })
            if header_end == 0:
                header_end = i

    # Set end lines for each chapter
    for i, chapter in enumerate(chapters):
        if i + 1 < len(chapters):
            chapter['end_line'] = chapters[i + 1]['start_line']
        else:
            chapter['end_line'] = len(lines)

    # Number mapping for filenames
    num_map = {
        'ONE': '01', 'TWO': '02', 'THREE': '03', 'FOUR': '04', 'FIVE': '05',
        'SIX': '06', 'SEVEN': '07', 'EIGHT': '08', 'NINE': '09', 'TEN': '10'
    }

    # Save header/intro content
    if header_end > 0:
        header_content = '\n'.join(lines[:header_end])
        header_file = output_path / '00-introduction.md'
        with open(header_file, 'w', encoding='utf-8') as f:
            f.write(header_content)
        print(f"Created: {header_file.name} ({len(header_content)} chars)")

    # Save each chapter
    for chapter in chapters:
        chapter_content = '\n'.join(lines[chapter['start_line']:chapter['end_line']])

        # Create safe filename
        safe_title = re.sub(r'[^\w\s-]', '', chapter['title'].lower())
        safe_title = re.sub(r'[\s]+', '-', safe_title.strip())
        safe_title = safe_title[:50]  # Limit length

        filename = f"{num_map[chapter['number']]}-{safe_title}.md"
        chapter_file = output_path / filename

        with open(chapter_file, 'w', encoding='utf-8') as f:
            f.write(chapter_content)

        print(f"Created: {filename} ({len(chapter_content)} chars)")

    # Create an index file
    index_content = "# PiCar-X V2.0 Manual - Index\n\n"
    index_content += "This manual has been split into the following chapters for easier LLM processing:\n\n"

    if header_end > 0:
        index_content += "- [00-introduction.md](./00-introduction.md) - Table of Contents and Overview\n"

    for chapter in chapters:
        safe_title = re.sub(r'[^\w\s-]', '', chapter['title'].lower())
        safe_title = re.sub(r'[\s]+', '-', safe_title.strip())[:50]
        filename = f"{num_map[chapter['number']]}-{safe_title}.md"
        index_content += f"- [{filename}](./{filename}) - {chapter['title']}\n"

    index_file = output_path / 'README.md'
    with open(index_file, 'w', encoding='utf-8') as f:
        f.write(index_content)
    print(f"\nCreated index: {index_file.name}")

    print(f"\nTotal: {len(chapters) + 1} files created in {output_dir}/")


if __name__ == '__main__':
    script_dir = Path(__file__).parent
    input_file = script_dir / 'picar-x-manual.md'
    output_dir = script_dir / 'manual-chapters'

    if not input_file.exists():
        print(f"Error: {input_file} not found. Run the PDF conversion first.")
        exit(1)

    split_markdown_by_chapters(str(input_file), str(output_dir))
